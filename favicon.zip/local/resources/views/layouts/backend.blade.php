
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>BBTEACHER</title>
    <!-- Bootstrap -->
    <link href="{{asset('local/public/contents/backend')}}/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="{{asset('local/public/contents/backend')}}/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="{{asset('local/public/contents/backend')}}/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="{{asset('local/public/contents/backend')}}/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
    @yield('page-style')
    <!-- Custom Theme Style -->
    <link href="{{asset('local/public/contents/backend')}}/build/css/custom.min.css" rel="stylesheet">
   
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
         
           <div class="navbar nav_title" style="border: 0;">
              <a href="{{URL::to('/')}}" target="__blank" class="site_title"><i class="fa fa-paw"></i> <span>BP Teacher</span></a>
            </div>

            <div class="clearfix"></div>
            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <ul class="nav side-menu">
                  <li><a href="{{route('admin_deshboard')}}"><i class="fa fa-home"></i> Deshboard</a></li>
                  <li><a href="{{route('admin_deshboard')}}"><i class="fa fa-user"></i> Adminstator</a></li>
                  <li><a href="{{route('admin_guardian.index')}}"><i class="fa fa-male"></i> Guardian</a></li>
                  <li><a href="{{route('admin_student.index')}}"><i class="fa fa-server"></i> Student</a></li>
                  <li><a href="{{route('admin_teacher.index')}}"><i class="fa fa-male"></i> Teacher</a></li>
                  <li><a href="{{route('admin_board.index')}}"><i class="fa fa-at"></i> Board</a></li>
                  <li><a href="{{route('admin_subject.index')}}"><i class="fa fa-book"></i>Subject</a></li>
                  <li><a href="{{route('teaching_class.index')}}"><i class="fa fa-university"></i>Class</a></li>
                  <li><a href="{{route('country.index')}}"><i class="fa fa-map"></i> Country</a></li>
                  <li><a href="{{route('admin_dis.index')}}"><i class="fa fa-random"></i> District</a></li>
                  <li><a href="{{route('admin_city.index')}}"><i class="fa fa-random"></i> City</a></li>
                  <li><a href="{{route('police_station.index')}}"><i class="fa fa-map"></i> Police Station</a></li>

                  <li><a href="{{route('admin_area.index')}}"><i class="fa fa-map"></i> Area</a></li>

         
                  <li><a href="{{route('admin_deshboard')}}"><i class="fa fa-trash"></i> Recycle Bin</a></li>
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
               <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                    @csrf
                 </form>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="{{asset('local/public/contents/backend')}}/images/img.jpg" alt="">  
                    @if(Auth::check()){{Auth::user()->name}}@endif
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="{{route('view_profile',Auth::user()->id)}}"> Profile</a></li>
                    <li>
                      <a href="javascript:;">
                        <span class="badge bg-red pull-right">50%</span>
                        <span>Settings</span>
                      </a>
                    </li>
                    <li><a href="javascript:;">Help</a></li>
                    <li>
                      <a href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                       <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                          @csrf
                       </form>
                    </li>
                  </ul>
                </li>

            <!--     <li role="presentation" class="dropdown">
                  <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-envelope-o"></i>
                    <span class="badge bg-green">6</span>
                  </a>
                  <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
                    <?php $recentiser=DB::table('users')->get()->take(4);?>
                    @foreach($recentiser as $getrecent_user)
                    <li>
                      <a>
                        <span class="image"><img src="{{asset('local/public/contents/backend')}}/images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    @endforeach
                    <li>
                      <div class="text-center">
                        <a>
                          <strong>See All Alerts</strong>
                          <i class="fa fa-angle-right"></i>
                        </a>
                      </div>
                    </li>
                  </ul>
                </li> -->
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

  @yield('content')
      </div>
    </div>

    
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>


 <!--    <script src="{{asset('local/public/contents/backend')}}/vendors/moment/min/moment.min.js"></script>
    <script src="{{asset('local/public/contents/backend')}}/vendors/bootstrap-daterangepicker/daterangepicker.js"></script> -->
    


   <!-- jQuery -->
   <script src="{{asset('local/public/contents/backend')}}/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="{{asset('local/public/contents/backend')}}/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
   <script src="{{asset('local/public/contents/backend')}}/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
   <script src="{{asset('local/public/contents/backend')}}/vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
   <script src="{{asset('local/public/contents/backend')}}/vendors/iCheck/icheck.min.js"></script>
    <!-- Chart.js -->
    <script src="{{asset('local/public/contents/backend')}}/vendors/Chart.js/dist/Chart.min.js"></script>
  <!-- jQuery Sparklines -->
    <script src="{{asset('local/public/contents/backend')}}/vendors/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
  <!-- Flot -->
    <script src="{{asset('local/public/contents/backend')}}/vendors/Flot/jquery.flot.js"></script>
    <script src="{{asset('local/public/contents/backend')}}/vendors/Flot/jquery.flot.pie.js"></script>
    <script src="{{asset('local/public/contents/backend')}}/vendors/Flot/jquery.flot.time.js"></script>
    <script src="{{asset('local/public/contents/backend')}}/vendors/Flot/jquery.flot.stack.js"></script>
    <script src="{{asset('local/public/contents/backend')}}/vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="{{asset('local/public/contents/backend')}}/vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="{{asset('local/public/contents/backend')}}/vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="{{asset('local/public/contents/backend')}}/vendors/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="{{asset('local/public/contents/backend')}}/vendors/DateJS/build/date.js"></script>

    @yield('page-script')
    <!-- Custom Theme Scripts -->
    <script src="{{asset('local/public/contents/backend')}}/build/js/custom.min.js"></script>

  </body>
</html>
