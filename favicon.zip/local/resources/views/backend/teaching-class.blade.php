  @extends('layouts.backend')
  @section('content')
  @section('page-style')
    @include('backend.template-parts.links.data-table-style')
    <style type="text/css">
     
      .nav-md .container.body .right_column {
        padding: 10px 20px 0;
        margin-left: 230px;
        height: 100vh
    } 
    .body{
      background: #F7F7F7;
     }
     @media(max-width: 991px){
      .nav-md .container.body .right_column {
        width: 100%;
        padding-right: 0;
        margin-left:0;
      }
     }
    </style>
  @endsection





        <!-- page content -->
        <div class="right_column">
          <div class="text-center">
         <button class="text-center btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i> Add Class</button>
          </div>
        <div class="x_content">
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Class Name</th>
                          <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $x=0;?>
                          @foreach($getdata as $data)
                          <?php $x++;?>
                        <tr>
                          <td>{{$x}}</td>
                          <td>{{$data->class_name}}</td>
                          <td>
                            @if($data->status==1)
                            <a href="{{route('deactive_status',$data->id)}}" id="deactive" class="btn btn-primary btn-xs" id="{{$data->id}}">Active</a>
                            @else
                             <a href="{{route('active_status',$data->id)}}" id="active" class="btn btn-danger btn-xs" id="{{$data->id}}">Deactive</a>
                            @endif
                          </td>
                          <td>
                            <a href="#" class="btn btn-primary btn-xs view_data" id="{{$data->id}}" data-toggle="modal" data-target="#View_Modal"><i class="fa fa-eye"></i> View</a>
                            <a href="" class="btn btn-info btn-xs edit_data" id="{{$data->id}}" data-toggle="modal" data-target="#Edit_Modal"><i class="fa fa-edit"></i> Edit</a>
                            <a href="#" class="btn btn-danger btn-xs trash" id="{{$data->id}}"><i class="fa fa-trash"></i> Delete</a>
                          </td>
                        </tr>
                          @endforeach
                      </tbody>
                    </table>
                  </div>
       
        </div>
        <!-- /page content -->



<!-- ============================================================

                 ALL MODAL HERE
  ===============================================================-->


<!-- Add Class Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Add New Class</h4>
      </div>
       <form action="{{route('teaching_class.store')}}" method="post">
        @csrf
        <div class="modal-body">
            <div class="form-group">
              <label for="recipient-name" class="control-label">Type Class Name </label>
              <input type="text" class="form-control" name="class_name" id="class-name" required="required">
            </div>
       
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- End Modal  -->


<!-- Edit -->
<div class="modal fade" id="Edit_Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Edit Class</h4>
      </div>
       <form action="" method="post" id="update_form">
        @csrf
       @method('PUT');
        <div class="modal-body">
            <div class="form-group">
              <label for="recipient-name" class="control-label">Type Class Name </label>
              <input type="text" class="form-control" name="class_name" id="edit_class" required="required">
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- Edit  -->
<!-- View Data -->
<div class="modal fade" id="View_Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header bg-primary text-center">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Class Details</h4>
      </div>
        <div class="modal-body">
            <table class="table table-striped">
              <tr>
                <td>Class Name</td>
                <td class="view_class_name"></td>
              </tr>
              <tr>
                <td>Status</td>
                <td class="view_status"></td>
              </tr>

            </table>
       
        </div>
    </div>
  </div>
</div>
<!-- End View Data  -->


  @section('page-script')
  @include('backend.template-parts.links.data-table')

  <script>
    $('.trash').click(function(){
    var id=$(this).attr('id');
       swal({
         title: "Are you sure?",
         text: "Do you really want to delete data!",
         icon: "warning",
         buttons: true,
         dangerMode: true,
       });
      $('.swal-button--confirm').click(function(){
        var url='{{route("teaching_class.destroy",":id")}}';
        url = url.replace(':id', id);
        var csrf_token=$('meta[name="csrf-token"]').attr('content');

        $.ajax({
           url:url,
           type:'POST',
           data:{'_method':'DELETE','_token': csrf_token },
           success:function(data){
             $('#msg').html('<div class="alert alert-success d-inline text-center bg-primary text-white" role="alert">Data Deleted Sucessfull</div>');
               $('#'+id).closest("tr").hide();

           }
       });
     });

    });
  </script>

  <!-- edit data -->
  <script>
    $('.edit_data').click(function(){

        var id=$(this).attr('id');
        var url='{{route("teaching_class.edit",":id")}}';
        var url = url.replace(':id', id);
        var url2='{{route("teaching_class.update",":id")}}';
        var url2 = url2.replace(':id', id);
        // edit
         $.ajax({
            url:url,
            type:'GET',
            dataType:'json',
            success:function(data){
               $('#edit_class').val(data.class_name);
               $('#update_form').attr('action',url2);
            }
        });
      });
  </script>

  <!-- viewdata data -->
  <script>
    $('.view_data').click(function(){
        var id=$(this).attr('id');
        var url='{{route("teaching_class.show",":id")}}';
        var url = url.replace(':id', id);
        // edit
         $.ajax({
            url:url,
            type:'GET',
            dataType:'json',
            success:function(data){
               $('.view_class_name').html(data.class_name);
               if(data.status == 1){
               $('.view_status').html('Active');
               }else{
               $('.view_status').html('Deactive');
               }
            }
        });
      });
  </script>

   



       @endsection

      @endsection

      