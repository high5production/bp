@extends('layouts.frontend')
@section('content')

		<!-- subject-area -->
		<section class="subject-area">
			<div class="container">
				<div class="row">
				@include('frontend.template-parts.teacher_sidebar')
					<div class="sub-content sub-content2 col-md-10 wow fadeInDown">
						<div class="row">
						<nav id="navv">
							<div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
								<a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">New Notice</a>
								<a class="nav-item nav-link" id="nav-home-tab" data-toggle="tab" href="#nav-homee" role="tab" aria-controls="nav-home" aria-selected="true">All Notice</a>
							</div>
						</nav>
						</div>
						<div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
							<div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
								<form action="{{route('teacher-notice.store')}}" method="post">
								 @csrf
								<div class="notice">
									@if(Auth::check())
									<input type="hidden" value="{{Auth::user()->id}}" name="user_id">
									@endif
									<h4>write a new notice</h4>
									<div class="form-group">
										<label for="notice_title">Notice Title</label>
										<input type="text" id="notice_title" class="form-control" name="n_title" placeholder="Add Your Notice Title" required>
									</div>
									<div class="form-group">
										<label for="notice">Notice Body</label>
										<textarea class="form-control" id="notice" placeholder="Write a Notice" name="n_des" required></textarea>
									</div>
									<ul>
										<li><button type="submit">Publish</button></li>
									</ul>
								</div>
							</form>
							</div>
							<div class="tab-pane fade" id="nav-homee" role="tabpanel" aria-labelledby="nav-home-tab">
								<div class="notice_all" style="overflow-y: scroll;height: 100vh">
									<h4>all notice</h4>
									@foreach($allnotice as $notice)
									<div class="notice_single" id="codepopular_{{$notice->id}}">
										<a href="#">
											<h5>{{$notice->n_title}}</h5>
											<p>{{$notice->n_des}}</p>
										</a>
										<div class="action_btn mt-2 text-right">
										 @if($notice->status== 1)
				                            <a href="{{route('t_notice_deactive',$notice->id)}}" id="deactive" class="btn btn-info btn-sm" id="{{$notice->id}}">Active</a>
				                            @else
				                             <a href="{{route('t_notice_active',$notice->id)}}" id="active" class="btn btn-warning btn-sm ml-2" id="{{$notice->id}}">Deactive</a>
				                            @endif
										
										<a href="javascript::void(0)" class="btn btn-success btn-sm edit_data m-1" id="{{$notice->id}}" data-toggle="modal" data-target="#Edit_Modal"> Edit </a>
										<a href="javascript::void(0)" class="btn btn-danger btn-sm trash" id="{{$notice->id}}">Delete</a>
									    </div>
									</div>
									@endforeach
							
								</div>
							</div>
							
							
						</div>
					</div>
				</div>
			</div>
		</section>




<!-- modal -->
<!-- Edit -->
<div class="modal fade" id="Edit_Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
       <form action="" method="post" id="update_notice">
        @csrf
       @method('PUT');
        <div class="modal-body">
            <div class="form-group">
              <label for="recipient-name" class="control-label">Notice Title </label>
              <input type="text" class="form-control" name="n_title" id="edit_n_title" required="required">
            </div>

             <div class="form-group">
              <label for="recipient-name" class="control-label">Notice Details </label>
              <textarea class="form-control" name="n_des" id="edit_n_des" required="required"></textarea>
            </div>
           
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- Edit  -->


<style>
	
	.swal-button--cancel{
		color:#fff !important;
	}

</style>


  @section('page_script')

  <script>
    $('.trash').click(function(){
    var id=$(this).attr('id');
       swal({
         title: "Are you sure?",
         text: "Do you really want to delete data!",
         icon: "warning",
         buttons: true,
         dangerMode: true,
       });
      $('.swal-button--confirm').click(function(){
        var url='{{route("teacher-notice.destroy",":id")}}';
        url = url.replace(':id', id);
        var csrf_token=$('meta[name="codepopular"]').attr('content');

        $.ajax({
           url:url,
           type:'POST',
           data:{'_method':'DELETE','_token': csrf_token },
           success:function(data){
             $('#msg').html('<div class="alert alert-success d-inline text-center bg-primary text-white" role="alert">Data Deleted Sucessfull</div>');
               $('#codepopular_'+id).hide();

           }
       });
     });

    });
  </script>

  <!-- edit data -->
  <script>
    $('.edit_data').click(function(){

        var id=$(this).attr('id');
        var url='{{route("teacher-notice.edit",":id")}}';
        var url = url.replace(':id', id);
        var url2='{{route("teacher-notice.update",":id")}}';
        var url2 = url2.replace(':id', id);
        // edit
         $.ajax({
            url:url,
            type:'GET',
            dataType:'json',
            success:function(data){
               $('#edit_n_title').val(data.n_title);
               $('#edit_n_des').val(data.n_des);
               $('#update_notice').attr('action',url2);
               
            }
        });
      });
  </script>


       @endsection



	@endsection