@extends('layouts.frontend')
@section('content')

		<!-- subject-area -->
		<section class="subject-area">
			<div class="container">
				<div class="row">
					@include('frontend.template-parts.student_sidebar')
					<div class="sub-content sub-content2 col-md-10 wow fadeInDown">
						<div class="row">
						<nav id="navv">
							<div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
								<a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Personal Info</a>
								<a class="nav-item nav-link" id="nav-home-tab" data-toggle="tab" href="#nav-homee" role="tab" aria-controls="nav-home" aria-selected="true">Fapther Info</a>
								<a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Mother Info</a>
							</div>
						</nav>
						</div>
						<div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
							<div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
							 <form action="{{route('student.update',$profile_id)}}" method="post">
							 	@csrf
							 	@method('put')
								<div class="student_inform">
									<h4>student information</h4>
									<div class="form-group row">
									    <label for="student_name" class="col-sm-3 col-form-label">Student Name</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="student_name" placeholder="Student Name" name="student_name" value="{{$student_info->student_name}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="class-grade-level" class="col-sm-3 col-form-label">Class/Grade/Level</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="class-grade-level" placeholder="lass/Grade/Level" name="class_grade_level" value="{{$student_info->class_grade_level}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="group" class="col-sm-3 col-form-label">Group</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="group" placeholder="Group Science/ Commerce/ Humanities/ Mixed" name="group" value="{{$student_info->group}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_subject" class="col-sm-3 col-form-label">Subjects Pursuing</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="s_subject" placeholder="Subjects Pursuing" name="subject_passing" value="{{$student_info->group}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="contact_no" class="col-sm-3 col-form-label">Contact Number</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="contact_no" placeholder="Contact Number" name="contact_no" value="{{$student_info->contact_no == null ? Auth::user()->phone : $student_info->contact_no}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_email" class="col-sm-3 col-form-label">Email</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="s_email" placeholder="Email Address" name="email" value="{{$student_info->email == null ? Auth::user()->email : $student_info->email}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_address" class="col-sm-3 col-form-label">Address</label>
									    <div class="col-sm-9">
									      <textarea class="form-control" id="s_address" placeholder=" House Name, House, Flat, Road, Police Station" name="address" autocomplete="off">{{$student_info->address}}</textarea>
									    </div>
									</div>

									<div class="form-group row">
									    <label for="s_address" class="col-sm-3 col-form-label">Area</label>
									    <div class="col-sm-9">
									      <textarea class="form-control" id="s_address" placeholder="Enter Area Here" name="area" autocomplete="off">{{$student_info->area}}</textarea>
									    </div>
									</div>
									
									<div class="form-group tab_select row">
										<label class="col-sm-3">Select District</label>
										<div class="col-sm-9">
											<select id="selectboxx" name="district" class="form-control">
											    <option value="">Select District</option>
											     @foreach($getdis as $dislist)
											       <option value="{{$dislist->id}}" {{$dislist->id == $student_info->district ? 'selected' : ''}}>{{$dislist->district_name}}</option>
											     @endforeach
											</select>
										</div>
									</div>

									<div class="form-group tab_select row">
										<label class="col-sm-3">Select Country</label>
										<div class="col-sm-9">
											<select id="selectboxx" name="country" class="form-control">
											    <option value="">Select Country</option>
											     @foreach($allcountry as $country)
											       <option value="{{$country->id}}" {{$country->id == $student_info->country ? 'selected' : ''}}>{{$country->country_name}}</option>
											     @endforeach
											</select>
										</div>
									</div>

									<div class="regis_button tab_sub">
									  	<button>save</button>
									</div>
								</div>
							</form>
							</div>
							<div class="tab-pane fade" id="nav-homee" role="tabpanel" aria-labelledby="nav-home-tab">
							<form action="{{route('student.update',$profile_id)}}" method="post">
							 	@csrf
							 	@method('put')
								<div class="student_inform">
									<h4>father information</h4>
									<div class="form-group row">
									    <label for="f_name" class="col-sm-3 col-form-label">Father Name</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="f_name" placeholder="Father Name" name="father_name" value="{{$student_info->father_name}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_number" class="col-sm-3 col-form-label">Contact Number</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="f_number" placeholder="Father contact no" name="father_contact_no" value="{{$student_info->f_number}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_email" class="col-sm-3 col-form-label">Email</label>
									    <div class="col-sm-9">
									      <input type="email" class="form-control" id="f_email" placeholder="Email Address" name="father_email" value="{{$student_info->email}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_address" class="col-sm-3 col-form-label">Address</label>
									    <div class="col-sm-9">
									      <textarea class="form-control" id="f_address" placeholder=" House Name, House, Flat, Road, Police Station" name="father_address">{{$student_info->father_address}}</textarea>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_profession" class="col-sm-3 col-form-label">Profession</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="f_profession" placeholder="Profession" name="Profession" value="{{$student_info->Profession}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_nid" class="col-sm-3 col-form-label">NID</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="f_nid" placeholder="NID Number" name="father_nid" value="{{$student_info->father_nid}}">
									    </div>
									</div>

									<div class="form-group row">
									    <label for="father_area" class="col-sm-3 col-form-label">Father Area</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="father_area" placeholder="Father Area" name="father_area" value="{{$student_info->father_area}}">
									    </div>
									</div>

									<div class="form-group tab_select row">
										<label class="col-sm-3">Select District</label>
										<div class="col-sm-9">
											<select id="selectboxx" name="district" class="form-control">
											    <option value="">Select District</option>
											     @foreach($getdis as $dislist)
											       <option value="{{$dislist->id}}" {{$dislist->id == $student_info->district ? 'selected' : ''}}>{{$dislist->district_name}}</option>
											     @endforeach
											</select>
										</div>
									</div>

									<div class="form-group tab_select row">
										<label class="col-sm-3">Select Country</label>
										<div class="col-sm-9">
											<select id="selectboxx" name="f_country" class="form-control">
											    <option value="">Select Country</option>
											     @foreach($allcountry as $country)
											       <option value="{{$country->id}}" {{$country->id == $student_info->f_country ? 'selected' : ''}}>{{$country->country_name}}</option>
											     @endforeach
											</select>
										</div>
									</div>
									<div class="regis_button tab_sub">
									  	<button>save</button>
									</div>
								</div>
							</form>
							</div>
							<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
							   <form action="{{route('student.update',$profile_id)}}" method="post">
							 	@csrf
							 	@method('put')
								<div class="student_inform">
									<h4>mother information</h4>
									<div class="form-group row">
									    <label for="m_name" class="col-sm-3 col-form-label">Mother Name</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="m_name" placeholder="Mother Name" name="mother_name" value="{{$student_info->mother_name}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="m_number" class="col-sm-3 col-form-label">Contact Number</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="m_number" placeholder="Mother contact no" name="mother_contact_no" value="{{$student_info->mother_contact_no}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="m_email" class="col-sm-3 col-form-label">Email</label>
									    <div class="col-sm-9">
									      <input type="email" class="form-control" id="m_email" placeholder="Email Address" name="mother_email" value="{{$student_info->mother_email}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="m_address" class="col-sm-3 col-form-label">Address</label>
									    <div class="col-sm-9">
									      <textarea class="form-control" id="m_address" placeholder=" House Name, House, Flat, Road, Police Station" name="mother_address">{{$student_info->mother_address}}</textarea>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="m_profession" class="col-sm-3 col-form-label">Profession</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="m_profession" placeholder="Profession" name="mother_rofession" value="{{$student_info->mother_rofession}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="m_nid" class="col-sm-3 col-form-label">NID</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="m_nid" placeholder="NID Number" name="mother_nid" value="{{$student_info->mother_nid}}">
									    </div>
									</div>	
									<div class="form-group row">
									    <label for="area" class="col-sm-3 col-form-label">Area</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="area" placeholder="Area" name="area" value="{{$student_info->area}}">
									    </div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">Select District</label>
										<div class="col-sm-9">
											<select id="selectboxx" name="mother_district" class="form-control">
											    <option value="">Select District</option>
											     @foreach($getdis as $dislist)
											       <option value="{{$dislist->id}}" {{$dislist->id == $student_info->mother_district ? 'selected' : ''}}>{{$dislist->district_name}}</option>
											     @endforeach
											</select>
										</div>
									</div>

									<div class="form-group tab_select row">
										<label class="col-sm-3">Select Country</label>
										<div class="col-sm-9">
											<select id="selectboxx" name="mother_country" class="form-control">
											    <option value="">Select Country</option>
											     @foreach($allcountry as $country)
											       <option value="{{$country->id}}" {{$country->id == $student_info->mother_country ? 'selected' : ''}}>{{$country->country_name}}</option>
											     @endforeach
											</select>
										</div>
									</div>
									<div class="regis_button tab_sub">
									  	<button>save</button>
									</div>
								</div>
							</form>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</section>

@endsection