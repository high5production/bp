<div class="sub-head sub_head22 col-md-2 wow fadeInDown">
	<h2>teacher information</h2>
	<ul>
		<li><a href="{{route('teacher_deshboard')}}">Profile</a></li>
		<li><a href="{{route('teacher_subscription')}}">Subscription fee</a></li>
		<li><a href="{{route('student_enroll_list')}}">Student List</a></li>
		<li><a href="{{route('teacher-notice.index')}}">Notice</a></li>
	</ul>
</div>