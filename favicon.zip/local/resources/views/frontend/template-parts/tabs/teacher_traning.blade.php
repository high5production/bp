
<div class="coching_palce">
	<div class="accordion" id="accordionExample">
	  @foreach($teacher_tranings as $t_traning)
	  <div class="card">
	    <div class="card-header" id="heading{{$t_traning->id}}">
	      <h2 data-toggle="collapse" data-target="#collapse{{$t_traning->id}}" aria-expanded="true" aria-controls="collapse{{$t_traning->id}}">
	        {{$t_traning->qualification}}	      
	      </h2>
	    </div>

	    <div id="collapse{{$t_traning->id}}" class="collapse" aria-labelledby="heading{{$t_traning->id}}" data-parent="#accordionExample">
	      <div class="card-body">
	      	<div class="text-center mb-3">
	      		<a class="text-right btn btn-danger" href="{{route('t_traning_destroy',$t_traning->id)}}">Delete</a>
                <br>
                <br>
				<form action="{{route('t_traning_update',$t_traning->id)}}" method="post">
						@csrf
                  
						@if(Auth::check())
						 <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
						 @endif
						<div class="infr_adress infr_head">
							
							<div class="">
								<div class="form-group row">
								    <label for="t_date1" class="col-sm-3 col-form-label">Training</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control datepicker_cp" value="{{$t_traning->traning_date}}" id="t_date1" placeholder="Training Date" name="traning_date" autocomplete="off" required>
								    </div>
								</div>
								<div class="form-group row">
								    <label for="t_quali" class="col-sm-3 col-form-label">Qualification</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="t_quali" value="{{$t_traning->qualification}}" placeholder="Training Qualification" name="qualification" required>
								    </div>
								</div>
								<div class="form-group row">
								    <label for="t_on" class="col-sm-3 col-form-label">Training On</label>
								    <div class="col-sm-9">
								    <input type="text" class="form-control" value="{{$t_traning->traning_on}}" id="t_on" placeholder="Training On" name="traning_on" required>
								    </div>
								</div>
								<div class="form-group row">
								    <label for="t_dura" class="col-sm-3 col-form-label">Training Duration</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" value="{{$t_traning->traning_duration}}" id="t_dura" placeholder="Training Duration" name="traning_duration" required>
								    </div>
								</div>
								<div class="form-group row">
								    <label for="t_give" class="col-sm-3 col-form-label">Given By</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" value="{{$t_traning->given_by}}" id="t_give" placeholder="Training Given By.." name="given_by" required>
								    </div>
								</div>
								<div class="form-group row">
								    <label for="t_orga" class="col-sm-3 col-form-label">Organized</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" value="{{$t_traning->organization}}" id="t_orga" placeholder="Training Organized By.." name="organization" required>
								    </div>
								</div>
								<div class="form-group row">
								    <label for="t_traina" class="col-sm-3 col-form-label">Trainer</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" value="{{$t_traning->trainer_name}}" id="t_traina" placeholder="Trainer"  name="trainer_name" required>
								    </div>
								</div>
								<div class="form-group row">
								    <label for="t_venue" class="col-sm-3 col-form-label">Venue</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" value="{{$t_traning->t_venue}}" id="t_venue" placeholder="Training Venue" name="t_venue" required>
								    </div>
								</div>
								<div class="regis_button tab_sub">
								  	<button>save</button>
								</div>
							</div>
						</div>
						</form>

	      	</div>
              

	      </div>
	    </div>
	  </div>
	  @endforeach
	 
	</div>
</div>



<form action="{{route('t_traning')}}" method="post">
		@csrf

		@if(Auth::check())
		 <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
		 @endif
		<div class="infr_adress infr_head">
			<h4 id="teaching2">teaching training <i class="fa fa-plus"></i></h4>
			<div class="hide_form2">
				<div class="form-group row">
				    <label for="t_date" class="col-sm-3 col-form-label">Training</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control datepicker_cp" id="t_date" placeholder="Training Date" name="traning_date" autocomplete="off" required>
				    </div>
				</div>
				<div class="form-group row">
				    <label for="t_quali" class="col-sm-3 col-form-label">Qualification</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="t_quali" placeholder="Training Qualification" name="qualification" required>
				    </div>
				</div>
				<div class="form-group row">
				    <label for="t_on" class="col-sm-3 col-form-label">Training On</label>
				    <div class="col-sm-9">
				    <input type="text" class="form-control" id="t_on" placeholder="Training On" name="traning_on" required>
				    </div>
				</div>
				<div class="form-group row">
				    <label for="t_dura" class="col-sm-3 col-form-label">Training Duration</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="t_dura" placeholder="Training Duration" name="traning_duration" required>
				    </div>
				</div>
				<div class="form-group row">
				    <label for="t_give" class="col-sm-3 col-form-label">Given By</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="t_give" placeholder="Training Given By.." name="given_by" required>
				    </div>
				</div>
				<div class="form-group row">
				    <label for="t_orga" class="col-sm-3 col-form-label">Organized</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="t_orga" placeholder="Training Organized By.." name="organization" required>
				    </div>
				</div>
				<div class="form-group row">
				    <label for="t_traina" class="col-sm-3 col-form-label">Trainer</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="t_traina" placeholder="Trainer"  name="trainer_name" required>
				    </div>
				</div>
				<div class="form-group row">
				    <label for="t_venue" class="col-sm-3 col-form-label">Venue</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="t_venue" placeholder="Training Venue" name="t_venue" required>
				    </div>
				</div>
				<div class="regis_button tab_sub">
				  	<button>save</button>
				</div>
			</div>
		</div>
		</form>