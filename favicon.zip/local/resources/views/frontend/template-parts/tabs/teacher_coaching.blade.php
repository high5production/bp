
<div class="coching_palce">
	<div class="accordion" id="accordionExample">
	  @foreach($teaching_places as $t_place)
	  <div class="card">
	    <div class="card-header" id="heading{{$t_place->id}}">
	      <h2 data-toggle="collapse" data-target="#collapse{{$t_place->id}}" aria-expanded="true" aria-controls="collapse{{$t_place->id}}">
	        {{$t_place->coaching_name}}	      
	      </h2>
	    </div>

	    <div id="collapse{{$t_place->id}}" class="collapse" aria-labelledby="heading{{$t_place->id}}" data-parent="#accordionExample">
	      <div class="card-body">
	      	<div class="text-center mb-3">
	      		<a class="text-right btn btn-danger" href="{{route('coaching_destroy',$t_place->id)}}">Delete</a>

	      	</div>
                <form action="{{route('coaching_place_update',$t_place->id)}}" method="post">
								@csrf

								@if(Auth::check())
								 <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
								 @endif
							
								<div class="infr_adress infr_head">
										<div class="form-group row">
										    <label for="c_name" class="col-sm-3 col-form-label">Coaching Name</label>
										    <div class="col-sm-9">
										      <input type="text" class="form-control" id="c_name" placeholder="Coaching Name" name="coaching_name" value="{{$t_place->coaching_name}}" required>
										    </div>
										</div>
										<div class="form-group row">
										    <label for="c_housee" class="col-sm-3 col-form-label">House</label>
										    <div class="col-sm-9">
										      <textarea class="form-control" id="c_housee" placeholder="House, House Number, Road Number" name="house" required>{{$t_place->house}}</textarea>
										    </div>
										</div>
										<div class="form-group row">
										    <label for="c_housee" class="col-sm-3 col-form-label">Road No</label>
										    <div class="col-sm-9">
										      <textarea class="form-control" id="c_housee" placeholder="House, House Number, Road Number" name="road_no" required>{{$t_place->road_no}}</textarea>
										    </div>
										</div>
										<div class="form-group row">
										    <label for="c_land" class="col-sm-3 col-form-label">Landmark</label>
										    <div class="col-sm-9">
										      <input type="text" class="form-control" id="c_land" name="Landmark" placeholder="Nearest Landmark" value="{{$t_place->Landmark}}" required>
										    </div>
										</div>
										<div class="form-group row">
										    <label for="c_office" class="col-sm-3 col-form-label">Post Office</label>
										    <div class="col-sm-9">
										      <input type="text" class="form-control" id="c_office" placeholder="Post Office" name="post_office" value="{{$t_place->post_office}}" required>
										    </div>
										</div>
										<div class="form-group row">
										    <label for="c_code" class="col-sm-3 col-form-label">Postal Code</label>
										    <div class="col-sm-9">
										      <input type="text" class="form-control" id="c_code" placeholder="Postal Code" name="post_code" value="{{$t_place->post_code}}" required>
										    </div>
										</div>
										<div class="form-group row">
										    <label for="maps" class="col-sm-3 col-form-label">Map Code</label>
										    <div class="col-sm-9">
										      <input type="text" class="form-control" id="maps" placeholder="Google Map Code Here" name="map" value="{{$t_place->map}}" required>
										    </div>
										</div>
										<div class="form-group tab_select row">
											<label class="col-sm-3">Area</label>
											<div class="col-sm-9">
												<select class="form-control" name="area">
												    <option value="">Select Area..</option>
												    @foreach($get_police_station as $police_station)
												     <option value="{{$police_station->id}}" {{$police_station->id == $t_place->area ? 'selected' : ''}}>{{$police_station->police_station}}</option>
												    @endforeach
												</select>
											</div>
										</div>	
									     <div class="form-group tab_select row">
											<label class="col-sm-3" for="police_station">Police Station</label>
											<div class="col-sm-9">
												<select class="form-control" name="p_station">
												    <option value="">Select Police Station..</option>
												    @foreach($get_police_station as $police_station)
												     <option value="{{$police_station->id}}" {{$police_station->id == $t_place->p_station ? 'selected' : ''}}>{{$police_station->police_station}}</option>
												    @endforeach
												</select>
											</div>
										</div>
										<div class="form-group tab_select row">
											<label class="col-sm-3">District</label>
											<div class="col-sm-9">
												<select class="form-control" name="district">
												    <option value="">Select District..</option>
												     @foreach($getdis as $disinfo)
 														<option value="{{$disinfo->id}}" {{$disinfo->id == $t_place->district ? 'selected' : ''}}>{{$disinfo->district_name}}</option>
												     @endforeach
												</select>
											</div>
										</div>
										<div class="form-group tab_select row">
											<label class="col-sm-3">Country</label>
											<div class="col-sm-9">
												<select class="form-control" name="country">
												    <option value="">Select Country..</option>
												     @foreach($allcountry as $country)
												       <option value="{{$country->id}}" {{$country->id == $t_place->country ? 'selected' : ''}}>{{$country->country_name}}</option>
												     @endforeach
												</select>
											</div>
										</div>
										<div class="regis_button tab_sub">
										  	<button>Update</button>
										  
										 
									    </div>
								</div>
								</form>



	      </div>
	    </div>
	  </div>
	  @endforeach
	 
	</div>
</div>




<style type="text/css">
	
	.coching_palce .card{
         background:transparent;
         border:none;
	}
   .coching_palce .card-header{
         background:transparent;
         border-bottom: none;
	}
	.coching_palce .card-body{
         color:#fff;
	}
	.coching_palce h2{
      margin:0;
      text-align:left;
      font-size: 15px;
      border-radius: 0px;
      border:1px solid #41bfb4;
	}

</style>



							<form action="{{route('coaching_place')}}" method="post">
								@csrf
								
								@if(Auth::check())
								 <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
								 @endif
								<div class="infr_adress infr_head">
									<h4 id="teaching">teaching places <i class="fa fa-plus"></i></h4>
									<div class="hide_form">
										<div class="form-group row">
										    <label for="c_name" class="col-sm-3 col-form-label">Coaching Name</label>
										    <div class="col-sm-9">
										      <input type="text" class="form-control" id="c_name" placeholder="Coaching Name" name="coaching_name" required>
										    </div>
										</div>
										<div class="form-group row">
										    <label for="c_housee" class="col-sm-3 col-form-label">House</label>
										    <div class="col-sm-9">
										      <textarea class="form-control" id="c_housee" placeholder="House, House Number, Road Number" name="house" required></textarea>
										    </div>
										</div>
										<div class="form-group row">
										    <label for="road_no" class="col-sm-3 col-form-label">Road No</label>
										    <div class="col-sm-9">
										      <textarea class="form-control" id="road_no" placeholder="Enter Road No" name="road_no" required></textarea>
										    </div>
										</div>
										<div class="form-group row">
										    <label for="c_land" class="col-sm-3 col-form-label">Landmark</label>
										    <div class="col-sm-9">
										      <input type="text" class="form-control" id="c_land" name="Landmark" placeholder="Nearest Landmark" required>
										    </div>
										</div>
										<div class="form-group row">
										    <label for="c_office" class="col-sm-3 col-form-label">Post Office</label>
										    <div class="col-sm-9">
										      <input type="text" class="form-control" id="c_office" placeholder="Post Office" name="post_office" required>
										    </div>
										</div>
										<div class="form-group row">
										    <label for="c_code" class="col-sm-3 col-form-label">Postal Code</label>
										    <div class="col-sm-9">
										      <input type="text" class="form-control" id="c_code" placeholder="Postal Code" name="post_code" required>
										    </div>
										</div>
										<div class="form-group row">
										    <label for="maps" class="col-sm-3 col-form-label">Map Code</label>
										    <div class="col-sm-9">
										      <input type="text" class="form-control" id="maps" placeholder="Google Map Code Here" name="map" required>
										    </div>
										</div>
										<div class="form-group tab_select row">
											<label class="col-sm-3">Select Area</label>
											<div class="col-sm-9">
												<select id="selectboxx" name="area">
												    <option value="">Select Area</option>
												    @foreach($get_police_station as $police_station)
												     <option value="{{$police_station->id}}">{{$police_station->police_station}}</option>
												    @endforeach
												</select>
											</div>
										</div>
										<div class="form-group tab_select row">
											<label class="col-sm-3">Police Station</label>
											<div class="col-sm-9">
												<select class="form-control" name="p_station">
												    <option value="">Select Police Station..</option>
												    @foreach($get_police_station as $police_station)
												     <option value="{{$police_station->id}}">{{$police_station->police_station}}</option>
												    @endforeach
												</select>
											</div>
										</div>
										<div class="form-group tab_select row">
											<label class="col-sm-3">District</label>
											<div class="col-sm-9">
												<select id="selectboxx" name="district">
												    <option value="">Select District..</option>
												     @foreach($getdis as $disinfo)
 														<option value="{{$disinfo->id}}">{{$disinfo->district_name}}</option>
												     @endforeach
												</select>
											</div>
										</div>
										<div class="form-group tab_select row">
											<label class="col-sm-3">Country</label>
											<div class="col-sm-9">
												<select id="selectboxx" name="country">
												    <option value="">Select Country..</option>
												     @foreach($allcountry as $country)
												       <option value="{{$country->id}}">{{$country->country_name}}</option>
												     @endforeach
												</select>
											</div>
										</div>
										<div class="regis_button tab_sub">
										  	<button>save</button>
										</div>
									</div>
								</div>
								</form>
