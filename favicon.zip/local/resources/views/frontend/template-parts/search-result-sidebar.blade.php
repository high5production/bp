
<?php 
use App\Models\admin_subject;
 $getdata = admin_subject::where('status',1)->orderByRaw('LENGTH(subject_name) asc')->get();
?>
             <div class="sub-head col-md-3" id="sub_border">
					<h2>subject</h2>
					<ul class="scroll">
						@foreach($getdata as $data)
						<li><a href="#" data-toggle="tooltip" data-placement="top" title="{{$data->boardname['board_name']}}">{{$data->subject_name}}<span class="board_color" style="background:{{$data->boardname['board_color']}}"></span></a></li>
						@endforeach
						
					</ul>
				</div>