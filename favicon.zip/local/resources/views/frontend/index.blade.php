
@extends('layouts.frontend')
@section('content')
	<!-- start home_search_area -->
	<section class="home_search_area">
		<div class="container">
			<div class="row">
				<div class="advence_search mtb">
					<img src="{{asset('local/public/contents/frontend')}}/images/logof.png" alt="logo">
					<div class="logob">
						<img src="{{asset('local/public/contents/frontend')}}/images/bpteacher.png" class="img-fluid">
					</div>
					<form action="{{route('search')}}">
						<div class="form-group form_pad">
						      <input type="search" class="form-control" id="name" placeholder="Search..." name="search">
						</div>
						<div class="class_click">
							  <a href="#" id="clickk">advanced serach</a>
						</div>
						<div class="serach_options">
							<div class="row">
								<select class="form-control option1" name="district">
								  	<option value="">Select District</option>
								    @foreach($district as $getdis)
								      <option value="{{$getdis->id}}">{{$getdis->district_name}}</option>
								    @endforeach
								</select>
								<select class="form-control option1" name="police_station">
								  	<option value="">Select Police Station</option>
								     @foreach($police_station as $p_station)
								      <option value="{{$p_station->id}}">{{$p_station->police_station}}</option>
								     @endforeach
								</select>
								<select  class="form-control option1" name="area">
									<option value="">Select Area</option>
									  @foreach($areas as $area)
								      <option value="{{$area->id}}">{{$area->area_name}}</option>
								     @endforeach

								</select>
								<select class="form-control option1" name="board">
								  	<option value="">Exam Board</option>
								    @foreach($boards as $board)
								     	<option value="{{$board->id}}">{{$board->board_name}}</option>
								    @endforeach
								</select>
								<select class="form-control option1" name="label">
								  	<option value="">Select Level&hellip;</option>
								    <option value="O Label">O Level</option>
								    <option value="A Lavel">A Lavel</option>
								</select>
								<select class="form-control option1" name="subject">
								  	<option value="">Select Subject&hellip;</option>
								    @foreach($subjects as $subject)
								     <option value="{{$subject->id}}">{{$subject->subject_name}}</option>
								    @endforeach
								</select>
							</div>
						</div>
						<div class="regis_button">
						  	<button>search</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</section>
@endsection