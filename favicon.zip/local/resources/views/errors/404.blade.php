@extends('layouts.frontend')
@section('content')



<div class="error">
         <h1>404</h1>
</div>


<style>
	.error{
		text-align: center;
		margin-top: 10%
	}
	.error h1{
        font-size:100px;
        color:#fff;
	}

</style>




@endsection