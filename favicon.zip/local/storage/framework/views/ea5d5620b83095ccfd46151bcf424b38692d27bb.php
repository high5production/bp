  
  <?php $__env->startSection('content'); ?>
  <?php $__env->startSection('page-style'); ?>
    <?php echo $__env->make('backend.template-parts.links.data-table-style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style type="text/css">
     
      .nav-md .container.body .right_column {
        padding: 10px 20px 0;
        margin-left: 230px;
        height: 100vh
    } 
    .body{
      background: #F7F7F7;
     }
     @media(max-width: 991px){
      .nav-md .container.body .right_column {
        width: 100%;
        padding-right: 0;
        margin-left:0;
      }
     }
    </style>
  <?php $__env->stopSection(); ?>


        <!-- page content -->
        <div class="right_column">
          <div class="text-center">
         <button class="text-center btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i> Add District</button>
          </div>
        <div class="x_content">
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>District Name</th>
                          <th>Country Name</th>
                          <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $x=0;?>
                          <?php $__currentLoopData = $getdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php $x++;?>
                        <tr>
                          <td><?php echo e($x); ?></td>
                          <td><?php echo e($data->district_name); ?></td>
                          <td>
                              <?php if(isset($data->country_name->country_name)): ?>  
                                <?php echo e($data->country_name->country_name); ?>

                              <?php else: ?>
                               <span class="btn-xs bg-red">This Country Deleted</span>
                              <?php endif; ?>
                          </td>
                          <td>
                            <?php if($data->status==1): ?>
                            <a href="<?php echo e(route('admin_dis_deactive',$data->id)); ?>" id="deactive" class="btn btn-primary btn-xs" id="<?php echo e($data->id); ?>">Active</a>
                            <?php else: ?>
                             <a href="<?php echo e(route('admin_dis_active',$data->id)); ?>" id="active" class="btn btn-danger btn-xs" id="<?php echo e($data->id); ?>">Deactive</a>
                            <?php endif; ?>
                          </td>
                          <td>
                            <a href="" class="btn btn-info btn-xs edit_data" id="<?php echo e($data->id); ?>" data-toggle="modal" data-target="#Edit_Modal"><i class="fa fa-edit"></i> Edit</a>
                            <a href="#" class="btn btn-danger btn-xs trash" id="<?php echo e($data->id); ?>"><i class="fa fa-trash"></i> Delete</a>
                          </td>
                        </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
       
        </div>
        <!-- /page content -->



<!-- ============================================================

                 ALL MODAL HERE
  ===============================================================-->
<!-- Add Class Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Add New District</h4>
      </div>
       <form action="<?php echo e(route('admin_dis.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
            <div class="form-group">
              <label for="recipient-name" class="control-label">Type District Name </label>
              <input type="text" class="form-control" name="district_name" required="required">
            </div>
            <div class="form-group">
              <label for="recipient-name" class="control-label">Select Country</label>
              <select class="form-control" name="country_id" required>
                <option value="">Select Country</option>
                <?php $__currentLoopData = $all_countrys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($country->id); ?>"><?php echo e($country->country_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
           
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- End Modal  -->


<!-- Edit -->
<div class="modal fade" id="Edit_Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Edit District</h4>
      </div>
       <form action="" method="post" id="update_form">
        <?php echo csrf_field(); ?>
       <?php echo method_field('PUT'); ?>;
        <div class="modal-body">
            <div class="form-group">
              <label for="recipient-name" class="control-label">Type District Name </label>
              <input type="text" class="form-control" name="district_name" id="edit_dis_name" required="required">
            </div>
             <label for="recipient-name" class="control-label">Edit Country Name</label>
            <select class="form-control" name="country_id">
                <?php $__currentLoopData = $all_countrys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allcountry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option id="edit_country<?php echo e($allcountry->id); ?>" value="<?php echo e($allcountry->id); ?>"><?php echo e($allcountry->country_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- Edit  -->
  <?php $__env->startSection('page-script'); ?>


  <?php echo $__env->make('backend.template-parts.links.data-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script>
    $('.trash').click(function(){
    var id=$(this).attr('id');
       swal({
         title: "Are you sure?",
         text: "Do you really want to delete data!",
         icon: "warning",
         buttons: true,
         dangerMode: true,
       });
      $('.swal-button--confirm').click(function(){
        var url='<?php echo e(route("admin_dis.destroy",":id")); ?>';
        url = url.replace(':id', id);
        var csrf_token=$('meta[name="csrf-token"]').attr('content');

        $.ajax({
           url:url,
           type:'POST',
           data:{'_method':'DELETE','_token': csrf_token },
           success:function(data){
             $('#msg').html('<div class="alert alert-success d-inline text-center bg-primary text-white" role="alert">Data Deleted Sucessfull</div>');
               $('#'+id).closest("tr").hide();

           }
       });
     });

    });
  </script>

  <!-- edit data -->
  <script>
    $('.edit_data').click(function(){

        var id=$(this).attr('id');
        var url='<?php echo e(route("admin_dis.edit",":id")); ?>';
        var url = url.replace(':id', id);
        var url2='<?php echo e(route("admin_dis.update",":id")); ?>';
        var url2 = url2.replace(':id', id);
        // edit
         $.ajax({
            url:url,
            type:'GET',
            dataType:'json',
            success:function(data){
               $('#edit_dis_name').val(data.district_name);
               $('#update_form').attr('action',url2);
               if(data.country_name.id){
                  $('#edit_country'+data.country_id).attr("selected","selected");
               }else{
                  $('#edit_country'+data.country_id).removeAttr("selected");
               }
             

            }
        });
      });
  </script>
       <?php $__env->stopSection(); ?>

      <?php $__env->stopSection(); ?>

      
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/backend/admin_district.blade.php ENDPATH**/ ?>