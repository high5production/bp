<?php $__env->startSection('content'); ?>



<div class="error">
         <h1>404</h1>
</div>


<style>
	.error{
		text-align: center;
		margin-top: 10%
	}
	.error h1{
        font-size:100px;
        color:#fff;
	}

</style>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/errors/404.blade.php ENDPATH**/ ?>