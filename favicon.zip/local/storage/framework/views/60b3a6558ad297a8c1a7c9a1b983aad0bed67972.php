<!DOCTYPE html>
<html>
<head>
    <title>Laravel Dependent Dropdown Example with demo</title>
    <script src="http://demo.itsolutionstuff.com/plugin/jquery.js"></script>
    <link rel="stylesheet" href="http://demo.itsolutionstuff.com/plugin/bootstrap-3.min.css">
</head>
<body>


<div class="container">
    <div class="panel panel-default">
      <div class="panel-heading">Select State and get bellow Related City</div>
      <div class="panel-body">
            <div class="form-group">
                <label for="title">Select State:</label>
                <select name="country" class="form-control" style="width:350px">
                    <option value="">--- Select State ---</option>
                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($country->id); ?>"><?php echo e($country->country_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="title">Select District:</label>
                <select name="district" class="form-control cp_district" style="width:350px">
                </select>
            </div> 
            <div class="form-group">
                <label for="title">Select City:</label>
                <select name="city" class="form-control cp_city" style="width:350px">
                </select>
            </div>
      </div>
    </div>
</div>


<script type="text/javascript">
    $(document).ready(function() {

        // get district after select country
        $('select[name="country"]').on('change', function() {
            var countryID = $(this).val();
            var url='<?php echo e(route("mydistrict",":countryID")); ?>';
            var url = url.replace(':countryID', countryID);
            if(countryID) {
                $.ajax({
                    url:url,
                    type: "GET",
                    dataType: "json",

                    success:function(data) {
                      $('.cp_district').empty(); 
                      $('.cp_district').append('<option value="">Select District </option>');
                      $.each(data, function(key, value) {
                      $('.cp_district').append('<option value="'+ key +'">'+ value +'</option>');
                        });


                    }
                });
            }else{
                $('.cp_district').empty();
            }  
        });

         // get city after select district 
         $('.cp_district').on('change', function() {
            var districtID = $(this).val();
            var url='<?php echo e(route("mycity",":districtID")); ?>';
            var url = url.replace(':districtID', districtID);
            if(districtID) {
                $.ajax({
                    url: url,
                    type: "GET",
                    dataType: "json",
                    success:function(data) {
                        $('.cp_city').empty();
                        $('.cp_city').append('<option value="">Select City </option>');
                        $.each(data, function(key, value) {
                        $('.cp_city').append('<option value="'+ key +'">'+ value +'</option>');
                        });


                    }
                });
            }else{
                $('.cp_city').empty();
            }  
        });
    });
</script>


</body>
</html><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/test.blade.php ENDPATH**/ ?>