 <!-- Datatables -->
    <link href="<?php echo e(asset('local/public/contents/backend')); ?>/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('local/public/contents/backend')); ?>/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('local/public/contents/backend')); ?>/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('local/public/contents/backend')); ?>/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('local/public/contents/backend')); ?>/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet"><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/backend/template-parts/links/data-table-style.blade.php ENDPATH**/ ?>