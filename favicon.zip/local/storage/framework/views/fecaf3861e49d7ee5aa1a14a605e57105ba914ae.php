<?php $__env->startSection('content'); ?>

	<section class="studentlist-area">
		<div class="container">
			<div class="row">
				<div class="teacher_information">
					<h4>teacher information</h4>
					<ul>
					<li><a href="<?php echo e(route('teacher_deshboard')); ?>">Profile</a></li>
					<li><a href="<?php echo e(route('teacher_subscription')); ?>">Subscription fee</a></li>
					<li><a href="<?php echo e(route('student_enroll_list')); ?>">Student List</a></li>
					<li><a href="<?php echo e(route('teacher-notice.index')); ?>">Notice</a></li>
					</ul>
				</div>
				<div class="student_information">
					<h4>student list</h4>
					<table class="table table-hover table-bordered">
					  <thead>
					    <tr>
					      <th scope="col">Student Name</th>
					      <th scope="col">Class</th>
					      <th scope="col">Send Sms</th>
					    </tr>
					  </thead>
					  <tbody>
					  	<?php $__currentLoopData = $all_enroll_student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e_student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					    <tr>
					      <td><?php echo e($e_student->get_enroll_student->student_name); ?></td>
					      <td><?php echo e($e_student->get_enroll_student->class_grade_level); ?></td>
					      <td><a href="#" data-toggle="modal" data-target="#exampleModalCenter">send sms</a></td>
					    </tr>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  </tbody>
					</table>
					<!-- Modal -->
					<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
					  <div class="modal-dialog modal-dialog-centered" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="exampleModalLongTitle">Write Your Message</h5>
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div class="modal-body">
					          <form action="student_list.html">
					          	<div class="form-group">
									  <label for="comment">Message:</label>
									  <textarea class="form-control" rows="5" id="comment"></textarea>
								</div> 
								<div class="regis_button">
								  	<button type="submit">send</button>
								</div>
					          </form>
					      </div>
					    </div>
					  </div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/frontend/student_list.blade.php ENDPATH**/ ?>