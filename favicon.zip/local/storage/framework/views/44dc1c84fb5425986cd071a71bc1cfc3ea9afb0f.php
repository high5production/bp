<?php $__env->startSection('content'); ?>
	<!-- start home_search_area -->
	<section class="home_search_area">
		<div class="container">
			<div class="row">
				<div class="advence_search mtb">
					<img src="<?php echo e(asset('local/public/contents/frontend')); ?>/images/logof.png" alt="logo">
					<div class="logob">
						<img src="<?php echo e(asset('local/public/contents/frontend')); ?>/images/bpteacher.png" class="img-fluid">
					</div>
					<form action="<?php echo e(route('search')); ?>">
						<div class="form-group form_pad">
						      <input type="search" class="form-control" id="name" placeholder="Search..." name="search">
						</div>
						<div class="class_click">
							  <a href="#" id="clickk">advanced serach</a>
						</div>
						<div class="serach_options">
							<div class="row">
								<select class="form-control option1" name="district">
								  	<option value="">Select District</option>
								    <?php $__currentLoopData = $district; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getdis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								      <option value="<?php echo e($getdis->id); ?>"><?php echo e($getdis->district_name); ?></option>
								    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<select class="form-control option1" name="police_station">
								  	<option value="">Select Police Station</option>
								     <?php $__currentLoopData = $police_station; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								      <option value="<?php echo e($p_station->id); ?>"><?php echo e($p_station->police_station); ?></option>
								     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<select  class="form-control option1" name="area">
									<option value="">Select Area</option>
									  <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								      <option value="<?php echo e($area->id); ?>"><?php echo e($area->area_name); ?></option>
								     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</select>
								<select class="form-control option1" name="board">
								  	<option value="">Exam Board</option>
								    <?php $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								     	<option value="<?php echo e($board->id); ?>"><?php echo e($board->board_name); ?></option>
								    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<select class="form-control option1" name="label">
								  	<option value="">Select Level&hellip;</option>
								    <option value="O Label">O Level</option>
								    <option value="A Lavel">A Lavel</option>
								</select>
								<select class="form-control option1" name="subject">
								  	<option value="">Select Subject&hellip;</option>
								    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								     <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->subject_name); ?></option>
								    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						<div class="regis_button">
						  	<button>search</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/frontend/index.blade.php ENDPATH**/ ?>