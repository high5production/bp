<div class="sub-head sub_head22 col-md-2 wow fadeInDown">
	<h2>teacher information</h2>
	<ul>
		<li><a href="<?php echo e(route('teacher_deshboard')); ?>">Profile</a></li>
		<li><a href="<?php echo e(route('teacher_subscription')); ?>">Subscription fee</a></li>
		<li><a href="<?php echo e(route('student_enroll_list')); ?>">Student List</a></li>
		<li><a href="<?php echo e(route('teacher-notice.index')); ?>">Notice</a></li>
	</ul>
</div><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/frontend/template-parts/teacher_sidebar.blade.php ENDPATH**/ ?>