<form action="<?php echo e(route('teacher.update',$profile_id)); ?>" method="post">
								<?php echo csrf_field(); ?>
								<?php echo method_field('put'); ?>
     								<div class="infr_adress">
									<h4>Education</h4>
									<div class="present_school">
										<h4>masters degree of education</h4>
										<div class="row">
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="m_instituite">Institution</label>
												    <input type="text" class="form-control" id="m_instituite" placeholder="Instituion" name="master_degree_ins" value="<?php echo e($teacher_info->master_degree_ins); ?>" required>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="m_major">Major</label>
												    <input type="text" class="form-control" id="m_major" placeholder="Major" name="master_degree_major"  value="<?php echo e($teacher_info->master_degree_major); ?>" required>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="m_year">Year</label>
												    <input type="text" name="master_degree_yar" class="form-control" id="m_year" placeholder="Year" value="<?php echo e($teacher_info->master_degree_yar); ?>" required>
												</div>
											</div>
										</div>
									</div><!-- present_school end -->
									<div class="present_school">
										<h4>bachelor degree of education</h4>
										<div class="row">
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="b_instituite">Institution</label>
												    <input type="text" class="form-control" id="b_instituite" placeholder="Instituion" value="<?php echo e($teacher_info->bachelor_degree_ins); ?>" name="bachelor_degree_ins" required>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="b_major">Major</label>
												    <input type="text" name="bachelor_degree_major" class="form-control" id="b_major" placeholder="Major" value="<?php echo e($teacher_info->bachelor_degree_major); ?>" required>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="b_year">Year</label>
												    <input type="text" name="bachelor_degree_year" class="form-control" id="b_year" placeholder="Year" value="<?php echo e($teacher_info->bachelor_degree_year); ?>" required>
												</div>
											</div>
										</div>
									</div><!-- present_school end -->
									<div class="present_school">
										<h4>a level or hsc of education</h4>
										<div class="row">
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="h_instituite">Institution</label>
												    <input type="text" class="form-control" id="h_instituite" placeholder="Instituion" name="alavel_or_hsc_ins" value="<?php echo e($teacher_info->alavel_or_hsc_ins); ?>" required>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="h_major">Major</label>
												    <input type="text" name="alavel_or_hsc_major" class="form-control" id="h_major" placeholder="Major"  value="<?php echo e($teacher_info->alavel_or_hsc_major); ?>" required>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="h_year">Year</label>
												    <input type="text" name="alavel_or_hsc_year" class="form-control" id="h_year" placeholder="Year"  value="<?php echo e($teacher_info->alavel_or_hsc_year); ?>" required>
												</div>
											</div>
										</div>
									</div><!-- present_school end -->
									<div class="present_school">
										<h4>o level or ssc of education</h4>
										<div class="row">
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="o_instituite">Institution</label>
												    <input type="text" class="form-control" id="o_instituite" placeholder="Instituion" name="olavel_or_ssc_ins" value="<?php echo e($teacher_info->olavel_or_ssc_ins); ?>" required>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="o_major">Major</label>
												    <input type="text" class="form-control" id="o_major" placeholder="Major" name="olavel_or_ssc_major"  value="<?php echo e($teacher_info->olavel_or_ssc_major); ?>" required>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="o_year">Year</label>
												    <input type="text" name="olavel_or_ssc_year" class="form-control" id="o_year" placeholder="Year"  value="<?php echo e($teacher_info->olavel_or_ssc_year); ?>" required>
												</div>
											</div>
										</div>
									</div><!-- present_school end -->
									<div class="regis_button tab_sub">
									  	<button>save</button>
									</div>
								</div>
							   </form><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/frontend/template-parts/tabs/teacher_education.blade.php ENDPATH**/ ?>