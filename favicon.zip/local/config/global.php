<?php

return [

	'demosite' => 'no',
	'demotxt' => 'Demo disabled'

	

];

?>