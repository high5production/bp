<?php $__env->startSection('content'); ?>



  <?php 

 
  echo mt_rand(1, 999999);


  ?>


	<section class="studentlist-area">
		<div class="container">
			<div class="row">
				<div class="teacher_information">
					<h4>teacher information</h4>
					<ul>
						<li><a href="teacher_information.html">profile</a></li>
						<li><a href="subscription.html">subscription fee</a></li>
						<li><a href="class.html">class</a></li>
						<li><a href="notice.html">notice</a></li>
					</ul>
				</div>
				<div class="student_information">
					<h4>student list</h4>
					<table class="table table-hover table-bordered">
					  <thead>
					    <tr>
					      <th scope="col">Student Name</th>
					      <th scope="col">Class</th>
					      <th scope="col">Send Sms</th>
					    </tr>
					  </thead>
					  <tbody>
					    <tr>
					      <td>Mark</td>
					      <td>Math</td>
					      <td><a href="#" data-toggle="modal" data-target="#exampleModalCenter">send sms</a></td>
					    </tr>
					    <tr>
					      <td>Jacob</td>
					      <td>Physics</td>
					      <td><a href="#" data-toggle="modal" data-target="#exampleModalCenter">send sms</a></td>
					    </tr>
					    <tr>
					      <td>Mark</td>
					      <td>Math</td>
					      <td><a href="#" data-toggle="modal" data-target="#exampleModalCenter">send sms</a></td>
					    </tr>
					    <tr>
					      <td>Jacob</td>
					      <td>Physics</td>
					      <td><a href="#" data-toggle="modal" data-target="#exampleModalCenter">send sms</a></td>
					    </tr>
					    <tr>
					      <td>Mark</td>
					      <td>Math</td>
					      <td><a href="#" data-toggle="modal" data-target="#exampleModalCenter">send sms</a></td>
					    </tr>
					    <tr>
					      <td>Jacob</td>
					      <td>Physics</td>
					      <td><a href="#" data-toggle="modal" data-target="#exampleModalCenter">send sms</a></td>
					    </tr>
					  </tbody>
					</table>
					<!-- Modal -->
					<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
					  <div class="modal-dialog modal-dialog-centered" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="exampleModalLongTitle">Write Your Message</h5>
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div class="modal-body">
					          <form action="student_list.html">
					          	<div class="form-group">
									  <label for="comment">Message:</label>
									  <textarea class="form-control" rows="5" id="comment"></textarea>
								</div> 
								<div class="regis_button">
								  	<button type="submit">send</button>
								</div>
					          </form>
					      </div>
					    </div>
					  </div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/frontend/student_list.blade.php ENDPATH**/ ?>