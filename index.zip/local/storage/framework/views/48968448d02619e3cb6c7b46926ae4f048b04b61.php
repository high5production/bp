
<?php 
use App\Models\admin_subject;
 $getdata = admin_subject::where('status',1)->get();
?>
             <div class="sub-head scroll col-md-3 wow fadeInDown" id="sub_border">
					<h2>subject</h2>
					<ul>
						<?php $__currentLoopData = $getdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><a href="#" data-toggle="tooltip" data-placement="top" title="<?php echo e($data->boardname->board_name); ?>"><?php echo e($data->subject_name); ?><span class="board_color" style="background:<?php echo e($data->boardname->board_color); ?>"></span></a></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</ul>
				</div><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/frontend/template-parts/search-result-sidebar.blade.php ENDPATH**/ ?>