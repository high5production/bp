<?php $__env->startSection('content'); ?>

		<!-- subject-area -->
		<section class="subject-area sub_height">
			<div class="container">
				<div class="row">
					<?php echo $__env->make('frontend.template-parts.teacher_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<div class="sub-content sub-content2 col-md-10 wow fadeInDown">
						<div class="row">
							<div class="subscription_area">
								<h4>payment info</h4>
								<form>
									<div class="form-group row">
									    <label for="area" class="col-sm-3 col-form-label">Bkash Number</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="area" placeholder="Bkash Number.." >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="slip" class="col-sm-3 col-form-label">Bank Payment Slip</label>
									    <div class="col-sm-9">
									      <input type="file" id="slip" placeholder="Bank Payment Slip" >
									    </div>
									</div>
									<div class="regis_button tab_sub">
									  	<button>submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/frontend/subscription.blade.php ENDPATH**/ ?>