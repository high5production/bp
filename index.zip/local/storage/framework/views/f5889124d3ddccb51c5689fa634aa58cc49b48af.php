<div class="sub-head sub_head22 col-md-2 wow fadeInDown">
	<h2>teacher information</h2>
	<ul>
		<li><a href="<?php echo e(route('teacher_deshboard')); ?>">profile</a></li>
		<li><a href="<?php echo e(route('teacher_subscription')); ?>">subscription fee</a></li>
		<li><a href="<?php echo e(route('teacher_class')); ?>">class</a></li>
		<li><a href="<?php echo e(route('teacher_notice')); ?>">notice</a></li>
	</ul>
</div><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/frontend/template-parts/teacher_sidebar.blade.php ENDPATH**/ ?>