  
  <?php $__env->startSection('content'); ?>
  <?php $__env->startSection('page-style'); ?>
    <?php echo $__env->make('backend.template-parts.links.data-table-style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style type="text/css">
     
      .nav-md .container.body .right_column {
        padding: 10px 20px 0;
        margin-left: 230px;
        height: 100vh
    } 
    .body{
      background: #F7F7F7;
     }
     @media(max-width: 991px){
      .nav-md .container.body .right_column {
        width: 100%;
        padding-right: 0;
        margin-left:0;
      }
     }
    </style>
  <?php $__env->stopSection(); ?>
        <!-- page content -->
        <div class="right_column">
          <div class="text-center">
         <button class="text-center btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i> Add Area</button>
          </div>
        <div class="x_content">
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Area Name</th>
                          <th>Police Station</th>
                          <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $x=0;?>
                          <?php $__currentLoopData = $getdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php $x++;?>
                        <tr>
                          <td><?php echo e($x); ?></td>
                          <td><?php echo e($data->area_name); ?></td>
                          <td>
                              <?php if(isset($data->police_station->police_station)): ?>  
                                <?php echo e($data->police_station->police_station); ?>

                              <?php else: ?>
                               <span class="btn-xs bg-red">This Police Station Deleted</span>
                              <?php endif; ?>
                          </td>
                          <td>
                            <?php if($data->status==1): ?>
                            <a href="<?php echo e(route('police_station_deactive',$data->id)); ?>" id="deactive" class="btn btn-primary btn-xs" id="<?php echo e($data->id); ?>">Active</a>
                            <?php else: ?>
                             <a href="<?php echo e(route('police_station_active',$data->id)); ?>" id="active" class="btn btn-danger btn-xs" id="<?php echo e($data->id); ?>">Deactive</a>
                            <?php endif; ?>
                          </td>
                          <td>
                            <a href="" class="btn btn-info btn-xs edit_data" id="<?php echo e($data->id); ?>" data-toggle="modal" data-target="#Edit_Modal"><i class="fa fa-edit"></i> Edit</a>
                            <a href="#" class="btn btn-danger btn-xs trash" id="<?php echo e($data->id); ?>"><i class="fa fa-trash"></i> Delete</a>
                          </td>
                        </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
       
        </div>
        <!-- /page content -->



<!-- ============================================================

                 ALL MODAL HERE
  ===============================================================-->
<!-- Add Class Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Police Station</h4>
      </div>
       <form action="<?php echo e(route('admin_area.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
            <div class="form-group">
              <label for="recipient-name" class="control-label">Type Police Station Name </label>
              <input type="text" class="form-control" name="area_name" required="required">
            </div>
            <div class="form-group">
              <label for="recipient-name" class="control-label">Select Police Station</label>
              <select class="form-control" name="police_station_id" required>
                <option value="">Select City</option>
                <?php $__currentLoopData = $policestations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($p_station->id); ?>"><?php echo e($p_station->police_station); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
           
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- End Modal  -->


<!-- Edit -->
<div class="modal fade" id="Edit_Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Edit Police Station</h4>
      </div>
       <form action="" method="post" id="update_form">
        <?php echo csrf_field(); ?>
       <?php echo method_field('PUT'); ?>;
        <div class="modal-body">
            <div class="form-group">
              <label for="recipient-name" class="control-label">Type Police Station Name</label>
              <input type="text" class="form-control" name="area_name" id="edit_area" required="required">
            </div>
            <label for="recipient-name" class="control-label">Select District</label>
            <select class="form-control" name="police_station_id">
                <?php $__currentLoopData = $policestations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option id="edit_station<?php echo e($p_station->id); ?>" value="<?php echo e($p_station->id); ?>"><?php echo e($p_station->police_station); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- Edit  -->



  <?php $__env->startSection('page-script'); ?>


  <?php echo $__env->make('backend.template-parts.links.data-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script>
    $('.trash').click(function(){
    var id=$(this).attr('id');
       swal({
         title: "Are you sure?",
         text: "Do you really want to delete data!",
         icon: "warning",
         buttons: true,
         dangerMode: true,
       });
      $('.swal-button--confirm').click(function(){
        var url='<?php echo e(route("police_station.destroy",":id")); ?>';
        url = url.replace(':id', id);
        var csrf_token=$('meta[name="csrf-token"]').attr('content');

        $.ajax({
           url:url,
           type:'POST',
           data:{'_method':'DELETE','_token': csrf_token },
           success:function(data){
             $('#msg').html('<div class="alert alert-success d-inline text-center bg-primary text-white" role="alert">Data Deleted Sucessfull</div>');
               $('#'+id).closest("tr").hide();

           }
       });
     });

    });
  </script>

  <!-- edit data -->
  <script>
    $('.edit_data').click(function(){

        var id=$(this).attr('id');
        var url='<?php echo e(route("admin_area.edit",":id")); ?>';
        var url = url.replace(':id', id);
        var url2='<?php echo e(route("admin_area.update",":id")); ?>';
        var url2 = url2.replace(':id', id);
        // edit
         $.ajax({
            url:url,
            type:'GET',
            dataType:'json',
            success:function(data){
               $('#edit_area').val(data.area_name);
               $('#update_form').attr('action',url2);
               if(data.police_station.id){
                  $('#edit_station'+data.police_station_id).attr("selected","selected");
               }else{
                  $('#edit_station'+data.police_station_id).removeAttr("selected");
               }
            }
        });
      });
  </script>


       <?php $__env->stopSection(); ?>

      <?php $__env->stopSection(); ?>

      
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/backend/admin_area.blade.php ENDPATH**/ ?>