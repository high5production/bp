<?php $__env->startSection('content'); ?>
	

	<!-- subject-area -->
	<section class="subject-area search_resultt">
		<div class="container">
			<div class="row">
				<?php echo $__env->make('frontend.template-parts.search-result-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<div class="sub-content scroll col-md-9">
					<h2>search result</h2>
					<!-- sub_content_single-->

                    <?php $__currentLoopData = $all_t_profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search_profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="sub_content_single">
						<div class="sub_con_img">
							<?php if($search_profile->photo != 'noimage.jpg'): ?>
								<img src="<?php echo e(asset('local/public/contents/upload/teacher/profile')); ?>/<?php echo e($search_profile->photo); ?>">
							<?php else: ?>
							 <img src="<?php echo e(asset('local/public/contents/frontend/images/noimage.jpg')); ?>" alt="image">
							<?php endif; ?>
							<div class="teacher_id">
								<h4>2255</h4>
							</div>
						</div>
						<div class="sub_con2">
							<div class="sub_name">
								<h5><?php echo e($search_profile->name); ?></h5>
								<h5>physics</h5>
								<h5><?php echo e($search_profile->teaching_level); ?></h5>
								<h5><?php echo e($search_profile->phone); ?></h5>
								<ul>
									<li><a href="<?php echo e($search_profile->facebook); ?>"><i class="fa fa-facebook"></i></a></li>
									<li><a href="<?php echo e($search_profile->twitter); ?>"><i class="fa fa-twitter"></i></a></li>
								</ul>
							</div>
							<div class="sub_con_text">
								<p><?php echo Str::words($search_profile->about, 45,'....'); ?><a href="<?php echo e(route('teacher_profile',$search_profile->id)); ?>">More Details</a></p>
							</div>
							<div class="teacher_id">
								<h4>2255</h4>
							</div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
				</div>
			</div>
		</div>
	</section>
	<!-- subject-area end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/frontend/search-result.blade.php ENDPATH**/ ?>