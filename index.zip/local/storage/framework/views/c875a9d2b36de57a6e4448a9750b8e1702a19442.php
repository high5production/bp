<?php $__env->startSection('content'); ?>
	<!-- subject-area -->
	<section class="subject-area">
		<div class="container">
			<div class="row">
				  	<?php echo $__env->make('frontend.template-parts.search-result-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<div class="sub-content scroll col-md-9 wow fadeInDown">
					<h2>teacher profile</h2>
					<!-- sub_content_single-->
					<div class="teacher_img">
							<?php if($view_profile->photo != 'noimage.jpg'): ?>
								<img src="<?php echo e(asset('local/public/contents/upload/teacher/profile')); ?>/<?php echo e($view_profile->photo); ?>">
							<?php else: ?>
							 <img src="<?php echo e(asset('local/public/contents/frontend/images/noimage.jpg')); ?>" alt="image">
							<?php endif; ?>
						
						<h4><?php echo e($view_profile->name); ?></h4>
						<p><?php echo e($view_profile->address); ?></p>
						<ul>
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
						</ul>
						<h4><?php echo e($view_profile->phone); ?></h4>
					</div>
					<div class="teacher_des">
						<p><?php echo e($view_profile->about); ?></p>
					</div>
					<!-- profile-info -->
					<div class="profile-info" style="overflow:hidden">
						<h3>profession</h3>
						<div class="row">
							<div class="col-lg-4 col-sm-6">
								<h4>Teaching Levels</h4>
								<p><?php echo e($view_profile->teaching_level); ?></p>
							</div>
							<div class="col-lg-4 col-sm-6">
								<h4>Present School: <?php echo e($view_profile->present_school); ?></h4>
								<p>Joining date: <?php echo e(Carbon\Carbon::parse($view_profile->present_joining_date)->format('d-M-y')); ?></p>
								<p>Position: <?php echo e($view_profile->present_position); ?></p>
							</div>
							<div class="col-lg-4 col-sm-6">
								<h4>Last School: <?php echo e($view_profile->last_school); ?></h4>
								<p>Till the Last Worked: <?php echo e(Carbon\Carbon::parse($view_profile->last_joning_date)->format('d-M-y')); ?></p>
								<p>Position: <?php echo e($view_profile->last_position); ?></p>
							</div>
						</div>
					</div>
					<!-- profile-info -->
					<div class="profile-info">
						<h3>education</h3>
						<div class="row">
							<div class="col-lg-3 col-sm-6">
								<h4>SSC</h4>
								<p><?php echo e($view_profile->olavel_or_ssc_ins); ?></p>
								<p>Major: <?php echo e($view_profile->olavel_or_ssc_major); ?></p>
								<p>Year: <?php echo e($view_profile->olavel_or_ssc_year); ?></p>
							</div>
							<div class="col-lg-3 col-sm-6">
								<h4>HSC</h4>
								<p>Institution: <?php echo e($view_profile->olavel_or_ssc_ins); ?></p>
								<p>Major: <?php echo e($view_profile->olavel_or_ssc_major); ?></p>
								<p>Year: <?php echo e($view_profile->olavel_or_ssc_year); ?></p>
							</div>
							<div class="col-lg-3 col-sm-6">
								<h4>BA (Honours)</h4>
								<p>Institution: <?php echo e($view_profile->bachelor_degree_ins); ?></p>
								<p>Major: <?php echo e($view_profile->bachelor_degree_major); ?></p>
								<p>Year: <?php echo e($view_profile->bachelor_degree_year); ?></p>
							</div>
							<div class="col-lg-3 col-sm-6">
								<h4>MA(Masters)</h4>
								<p>Institution: <?php echo e($view_profile->master_degree_ins); ?></p>
								<p>Major: <?php echo e($view_profile->master_degree_major); ?></p>
								<p>Year: <?php echo e($view_profile->master_degree_yar); ?></p>
							</div>
						</div>
					</div>
					<!-- profile-info -->
					<div class="profile-info">
						<h3>Attached Coaching Place(s)</h3>
						<p>When did the Coaching centre was established?: 
							<?php echo e(\Carbon\Carbon::parse($view_profile->coaching_establish_date)->format('d/m/Y')); ?></p>
						<p><?php echo e($view_profile->other_subject); ?></p>
					</div>
					<!-- profile-info -->
					<div class="profile-info">
						<h3>Teaching Place(s)</h3>
                        <?php $__currentLoopData = $teaching_place; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t_place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php  $police = 'App\Models\police_station'::where('id', $t_place->p_station)->get();
                        
                        ?>
                        <hr>
						<div class="row">
							<div class="col-lg-4 col-sm-6">
								<h4>Teaching Place: </h4>
								<p>Coaching Center Name:<?php echo e($t_place->coaching_name); ?></p>
								<p>House: <?php echo e($t_place->house); ?></p>
								<p>Road Number: <?php echo e($t_place->road_no); ?></p>
							</div>
							<div class="col-lg-4 col-sm-6">
								<p>Police Station:
								 <?php $__currentLoopData = $police; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          	        <?php echo e($p->police_station); ?>

                          	   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </p>
								<p>Area: <?php echo e($t_place->area); ?></p>
								<p>Post Office: <?php echo e($t_place->post_office); ?></p>
							</div>
							<div class="col-lg-4 col-sm-6">
								<p>Postal Code: <?php echo e($t_place->post_code); ?></p>
								<p>District: <?php echo e($t_place->t_place_district->district_name); ?></p>
								<p>Country: <?php echo e($t_place->t_place_country->country_name); ?></p>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<!-- profile-info -->
					<div class="profile-info">
						<h3>Teaching Training(s)</h3>
						<table class="table table-bordered ">
						  <thead class="">
						    <tr>
						      <th scope="col">Date</th>
						      <th scope="col">Qualification</th>
						      <th scope="col">Training on</th>
						      <th scope="col">Duration</th>
						      <th scope="col">Given by</th>
						      <th scope="col">Organized by</th>
						      <th scope="col">Trainer(s)</th>
						      <th scope="col">Venue</th>
						    </tr>
						  </thead>
						  <tbody>
						  	<?php $__currentLoopData = $view_t_traning; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t_traning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    <tr>
						      <th scope="row"><?php echo e($t_traning->traning_date); ?></th>
						      <td><?php echo e($t_traning->qualification); ?></td>
						      <td><?php echo e($t_traning->traning_on); ?></td>
						      <td><?php echo e($t_traning->traning_duration); ?></td>
						      <td><?php echo e($t_traning->given_by); ?></td>
						      <td><?php echo e($t_traning->organization); ?></td>
						      <td><?php echo e($t_traning->trainer_name); ?></td>
						      <td><?php echo e($t_traning->t_venue); ?></td>
						    </tr>
						    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  </tbody>
						
						</table>
					</div>
					<!-- profile-info -->
					<div class="profile-info">
						<h3>Address</h3>
						<p><?php echo e($view_profile->address); ?></p>
						<h4 style="padding-bottom: 10px;">Address on Google Map</h4>
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3652.1703918980825!2d90.38039151452398!3d23.74130248459384!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8b7a55cd36f%3A0xfcc5b021faff43ea!2sCreative%20IT%20Institute!5e0!3m2!1sen!2sbd!4v1568804774459!5m2!1sen!2sbd" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
					</div>

				</div>
			</div>
		</div>
	</section>



	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/frontend/teacher_profile.blade.php ENDPATH**/ ?>