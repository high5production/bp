<div class="sub-head sub_head22 col-md-2 wow fadeInDown">
	<h2>Guardian information</h2>
	<ul>
		<li><a href="<?php echo e(route('guardian_deshboard')); ?>">personal info</a></li>
		<li><a href="<?php echo e(route('student_class')); ?>">class</a></li>
		<li><a href="<?php echo e(route('student_notice')); ?>">notice</a></li>
	</ul>
</div><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/frontend/template-parts/guardian_sidebar.blade.php ENDPATH**/ ?>