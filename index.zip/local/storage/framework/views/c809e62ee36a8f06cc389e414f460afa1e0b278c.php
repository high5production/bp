<?php $__env->startSection('content'); ?>

		<!-- subject-area -->
		<section class="subject-area sub_heightt">
			<div class="container">
				<div class="row">
					<?php echo $__env->make('frontend.template-parts.student_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<div class="sub-content sub-content2 col-md-10 wow fadeInDown">
						<div class="row">
						<nav id="navv">
							<div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
								<a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Personal Info</a>
								<a class="nav-item nav-link" id="nav-home-tab" data-toggle="tab" href="#nav-homee" role="tab" aria-controls="nav-home" aria-selected="true">Fapther Info</a>
								<a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Mother Info</a>
							</div>
						</nav>
						</div>
						<div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
							<div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
								<div class="student_inform">
									<h4>student information</h4>
									<div class="form-group row">
									    <label for="s_name" class="col-sm-3 col-form-label">Student Name</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="s_name" placeholder="Student Name" >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_class" class="col-sm-3 col-form-label">Class/Grade/Level</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="s_class" placeholder="lass/Grade/Level" >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_group" class="col-sm-3 col-form-label">Group</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="s_group" placeholder="Group Science/ Commerce/ Humanities/ Mixed" >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_subject" class="col-sm-3 col-form-label">Subjects Pursuing</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="s_subject" placeholder="Subjects Pursuing" >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_phn" class="col-sm-3 col-form-label">Contact Number</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="s_phn" placeholder="Contact Number" >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_email" class="col-sm-3 col-form-label">Email</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="s_email" placeholder="Email Address" >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_address" class="col-sm-3 col-form-label">Address</label>
									    <div class="col-sm-9">
									      <textarea class="form-control" id="s_address" placeholder=" House Name, House, Flat, Road, Police Station"></textarea>
									    </div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">Area</label>
										<div class="col-sm-9">
											<select id="selectboxx">
											    <option value="">Select Area..</option>
											    <option value="january">Mohammadpur</option>
											    <option value="february">Uttara</option>
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">District</label>
										<div class="col-sm-9">
											<select id="selectboxx">
											    <option value="">Select District..</option>
											    <option value="january">Dhaka</option>
											    <option value="february">Pabna</option>
											</select>
										</div>
									</div>
									<div class="regis_button tab_sub">
									  	<button>save</button>
									</div>
								</div>
							</div>
							<div class="tab-pane fade" id="nav-homee" role="tabpanel" aria-labelledby="nav-home-tab">
								<div class="student_inform">
									<h4>father information</h4>
									<div class="form-group row">
									    <label for="f_name" class="col-sm-3 col-form-label">Father Name</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="f_name" placeholder="Father Name" >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_number" class="col-sm-3 col-form-label">Contact Number</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="f_number" placeholder="lass/Grade/Level" >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_email" class="col-sm-3 col-form-label">Email</label>
									    <div class="col-sm-9">
									      <input type="email" class="form-control" id="f_email" placeholder="Email Address" >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_address" class="col-sm-3 col-form-label">Address</label>
									    <div class="col-sm-9">
									      <textarea class="form-control" id="f_address" placeholder=" House Name, House, Flat, Road, Police Station"></textarea>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_profession" class="col-sm-3 col-form-label">Profession</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="f_profession" placeholder="Profession" >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_nid" class="col-sm-3 col-form-label">NID</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="f_nid" placeholder="NID Number" >
									    </div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">Area</label>
										<div class="col-sm-9">
											<select id="selectboxx">
											    <option value="">Select Area..</option>
											    <option value="january">Mohammadpur</option>
											    <option value="february">Uttara</option>
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">District</label>
										<div class="col-sm-9">
											<select id="selectboxx">
											    <option value="">Select District..</option>
											    <option value="january">Dhaka</option>
											    <option value="february">Pabna</option>
											</select>
										</div>
									</div>
									<div class="regis_button tab_sub">
									  	<button>save</button>
									</div>
								</div>
							</div>
							<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
								<div class="student_inform">
									<h4>mother information</h4>
									<div class="form-group row">
									    <label for="m_name" class="col-sm-3 col-form-label">Mother Name</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="m_name" placeholder="Mother Name" >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="m_number" class="col-sm-3 col-form-label">Contact Number</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="m_number" placeholder="lass/Grade/Level" >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="m_email" class="col-sm-3 col-form-label">Email</label>
									    <div class="col-sm-9">
									      <input type="email" class="form-control" id="m_email" placeholder="Email Address" >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="m_address" class="col-sm-3 col-form-label">Address</label>
									    <div class="col-sm-9">
									      <textarea class="form-control" id="m_address" placeholder=" House Name, House, Flat, Road, Police Station"></textarea>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="m_profession" class="col-sm-3 col-form-label">Profession</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="m_profession" placeholder="Profession" >
									    </div>
									</div>
									<div class="form-group row">
									    <label for="m_nid" class="col-sm-3 col-form-label">NID</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="m_nid" placeholder="NID Number" >
									    </div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">Area</label>
										<div class="col-sm-9">
											<select id="selectboxx">
											    <option value="">Select Area..</option>
											    <option value="january">Mohammadpur</option>
											    <option value="february">Uttara</option>
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">District</label>
										<div class="col-sm-9">
											<select id="selectboxx">
											    <option value="">Select District..</option>
											    <option value="january">Dhaka</option>
											    <option value="february">Pabna</option>
											</select>
										</div>
									</div>
									<div class="regis_button tab_sub">
									  	<button>save</button>
									</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/frontend/student_profile.blade.php ENDPATH**/ ?>