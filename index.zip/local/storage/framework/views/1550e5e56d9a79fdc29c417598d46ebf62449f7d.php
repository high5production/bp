<!DOCTYPE html>
<html>
<head>
  <meta name="description" content="Free Web tutorials">
  <meta name="keywords" content="HTML,CSS,XML,JavaScript">
  <meta name="author" content="John Doe">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>BP Home</title>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('local/public/contents/frontend')); ?>/css/animate.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('local/public/contents/frontend')); ?>/css/bootstrap.min.css">
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('local/public/contents/frontend')); ?>/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('local/public/contents/frontend')); ?>/css/responsive.css">
	<!-- google-fonts -->
	<link href="https://fonts.googleapis.com/css?family=Big+Shoulders+Display:400,700,900&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Alegreya+Sans:400,500&display=swap" rel="stylesheet">
</head>
<body>
	<div class="full_body">
		<!-- header-area start -->
		<header class="header-area wow fadeInDown">
			<div class="container">
				<div class="row">
					<div class="home-header-menu">
						<nav class="navbar navbar-expand-lg navbar-light">
						  <a class="navbar-brand" href="index.html"></a>
						  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						    <span class="navbar-toggler-icon"></span>
						  </button>

						  <div class="collapse navbar-collapse" id="navbarSupportedContent">
						    <ul class="navbar-nav text-center">
						      <li class="nav-item">
						        <a class="nav-link nav_back1" href="<?php echo e(URL::to('/')); ?>">Home <span class="sr-only">(current)</span></a>
						      </li>
						      <li class="nav-item">
						        <a class="nav-link nav_back2" href="#">About</a>
						      </li>
						      <li class="nav-item">
						        <a class="nav-link nav_back3" href="#">Service</a>
						      </li>
						      <li class="nav-item">
						        <a class="nav-link" href="#">notice</a>
						      </li>
						      <li class="nav-item">
						        <a class="nav-link nav_back3" href="#">lessons</a>
						      </li>
						      <li class="nav-item">
						        <a class="nav-link nav_back2" href="#">download</a>
						      </li>
						      <li class="nav-item">
						        <a class="nav-link nav_back1" href="#">contact</a>
						      </li>
						      <li class="nav-item">
						      	<?php if(Auth::check()): ?>
						        <a class="nav-link login"href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                                 <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                 <?php echo csrf_field(); ?>
                                 </form>
						        <?php else: ?>
						           <a class="nav-link login" href="<?php echo e(route('login')); ?>">login</a>
						        <?php endif; ?>
						      </li>
						    </ul>
						  </div>
						</nav>
					</div>
					<?php if(! Request::is('/')): ?> 
					<div class="logo-area">
						<div class="logo_img">
							<img src="<?php echo e(asset('local/public/contents/frontend')); ?>/images/bpteacher.png" alt="img">
						</div>
						<div class="logo_search">
							<form>
								<input type="search" name="">
								<button>search</button>
							</form>
						</div>
					</div>
					<?php endif; ?>
				</div>
			</div>
		</header><!-- end header-area -->
     <?php echo $__env->yieldContent('content'); ?>
	<!-- footer-area -->
	<footer class="footer-area">
		<p>&copy; blueporise.com</p>
	</footer>
	</div>
	<script src="<?php echo e(asset('local/public/contents/frontend')); ?>/js/jquery-3.4.1.min.js"></script>
	<script src="https://use.fontawesome.com/865d34d15b.js"></script>

    <script type="text/javascript" src="https://www.jqueryscript.net/demo/Image-Preview-Before-Uploading-jQuery-Image-Reader/jquery.imagereader-1.1.0.js"></script>

	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<script src="<?php echo e(asset('local/public/contents/frontend')); ?>/js/popper.min.js"></script>
	<script src="<?php echo e(asset('local/public/contents/frontend')); ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('local/public/contents/frontend')); ?>/js/jquery.nicescroll.min.js"></script>
    <script> 
		$(document).ready(function(){
		  $("#clickk").click(function(){
		    $(".serach_options").slideToggle('100');
		    return false;
		  });
		});
	</script>

	<script type="text/javascript"> 
       $('#photo').imageReader();

    
	</script>

    <script>
		$(document).ready(function(){
		  $('[data-toggle="tooltip"]').tooltip();   
		});
		$(document).ready(function(){
			$(".scroll").niceScroll({
				cursorwidth:6,
				cursoropacitymin:0.4,
				cursorcolor:'#fff',
				cursorborder:'none',
				cursorborderradius:4,
				autohidemode:'leave',
				background: '#70B3B3'
			}); 
		});
		
	</script>
	<script> 
		$(document).ready(function(){
		  $("#teaching").click(function(){
		    $(".hide_form").slideToggle('100');
		  });
		  $("#teaching2").click(function(){
		    $(".hide_form2").slideToggle('100');
		  });
		});
	</script>

	  <script>
	  $( function() {
	    $( ".datepicker_cp" ).datepicker({
	    	  dateFormat: "yy-mm-dd",
	    });
	  } );
  </script>


<script type="text/javascript">
$(document).ready(function(){
	$('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
		localStorage.setItem('activeTab', $(e.target).attr('href'));
	});
	var activeTab = localStorage.getItem('activeTab');
	if(activeTab){
		$('#nav-tab a[href="' + activeTab + '"]').tab('show');
	}
});
</script>

</body>
</html><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/layouts/frontend.blade.php ENDPATH**/ ?>