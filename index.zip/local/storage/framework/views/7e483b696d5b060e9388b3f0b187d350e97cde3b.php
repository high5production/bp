  
  <?php $__env->startSection('content'); ?>
  <?php $__env->startSection('page-style'); ?>
    <?php echo $__env->make('backend.template-parts.links.data-table-style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style type="text/css">
     
      .nav-md .container.body .right_column {
        padding: 10px 20px 0;
        margin-left: 230px;
        height: 100vh
    } 
    .body{
      background: #F7F7F7;
     }
     @media(max-width: 991px){
      .nav-md .container.body .right_column {
        width: 100%;
        padding-right: 0;
        margin-left:0;
      }
     }
    </style>
  <?php $__env->stopSection(); ?>
        <!-- page content -->
        <div class="right_column">



        



        
        <div class="x_content">
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Student Name</th>
                          <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $x=0;?>
                          <?php $__currentLoopData = $getdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php $x++;?>
                        <tr>
                          <td><?php echo e($x); ?></td>
                          <td><?php echo e($data->name); ?></td>
                          <td>
                            <?php if($data->status==1): ?>
                            <a href="<?php echo e(route('admin_teacher_deactive',$data->id)); ?>" id="deactive" class="btn btn-primary btn-xs" id="<?php echo e($data->id); ?>">Active</a>
                            <?php else: ?>
                             <a href="<?php echo e(route('admin_teacher_active',$data->id)); ?>" id="active" class="btn btn-danger btn-xs" id="<?php echo e($data->id); ?>">Deactive</a>
                            <?php endif; ?>
                          </td>
                          <td>
                            <a href="#" class="btn btn-primary btn-xs view_data" id="<?php echo e($data->id); ?>" data-toggle="modal" data-target="#View_Modal"><i class="fa fa-eye"></i> View</a>
                            <a href="#" class="btn btn-danger btn-xs trash" id="<?php echo e($data->id); ?>"><i class="fa fa-trash"></i> Delete</a>
                          </td>
                        </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
       
        </div>
        <!-- /page content -->


<!-- ============================================================

                 ALL MODAL HERE
  ===============================================================-->

<!-- View Data -->
<div class="modal fade bs-example-modal-lg" id="View_Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-body">
          <div class="modal-header bg-primary text-center">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" style="color:#fff">&times;</span></button>
            <h4 class="modal-title" id="exampleModalLabel">Teacher Details</h4>
          </div>
            <table class="table table-striped">
              <tr>
                <td>Name</td>
                <td class="view_student_name"></td>
              </tr>
               <tr>
                <td>Email</td>
                <td class="view_student_email"></td>
              </tr>
               <tr>
                <td>Phone</td>
                <td class="view_s_phone"></td>
              </tr>
              <tr>
                <td>Status</td>
                <td class="view_status"></td>
              </tr>

            </table>
        </div> 
        <!-- End Student Details --> 
       <div class="modal-body">
          <div class="modal-header bg-primary text-center">
            <h4 class="modal-title" id="exampleModalLabel">Eucation Qualification</h4>
          </div>
            <table class="table table-striped">
              <tr>
                <td>Name</td>
                <td class="view_student_name"></td>
              </tr>
               <tr>
                <td>Email</td>
                <td class="view_student_email"></td>
              </tr>
               <tr>
                <td>Phone</td>
                <td class="view_s_phone"></td>
              </tr>
              <tr>
                <td>Status</td>
                <td class="view_status"></td>
              </tr>

            </table>
        </div> <!--End  Father Details --->
        <div class="modal-body">
          <div class="modal-header bg-primary text-center">
            <h4 class="modal-title" id="exampleModalLabel">Coaching Place</h4>
          </div>
            <table class="table table-striped">
              <tr>
                <td>Name</td>
                <td class="view_student_name"></td>
              </tr>
               <tr>
                <td>Email</td>
                <td class="view_student_email"></td>
              </tr>
               <tr>
                <td>Phone</td>
                <td class="view_s_phone"></td>
              </tr>
              <tr>
                <td>Status</td>
                <td class="view_status"></td>
              </tr>

            </table>
        </div> <!-- End Mother Details -->
    </div>
  </div>
</div>
<!-- End View Data  -->


  <?php $__env->startSection('page-script'); ?>
  <?php echo $__env->make('backend.template-parts.links.data-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script>
    $('.trash').click(function(){
    var id=$(this).attr('id');
       swal({
         title: "Are you sure?",
         text: "Do you really want to delete data!",
         icon: "warning",
         buttons: true,
         dangerMode: true,
       });
      $('.swal-button--confirm').click(function(){
        var url='<?php echo e(route("admin_teacher.destroy",":id")); ?>';
        url = url.replace(':id', id);
        var csrf_token=$('meta[name="csrf-token"]').attr('content');

        $.ajax({
           url:url,
           type:'POST',
           data:{'_method':'DELETE','_token': csrf_token },
           success:function(data){
             $('#msg').html('<div class="alert alert-success d-inline text-center bg-primary text-white" role="alert">Data Deleted Sucessfull</div>');
               $('#'+id).closest("tr").hide();

           }
       });
     });

    });
  </script>


  <!-- viewdata data -->
  <script>
    $('.view_data').click(function(){
        var id=$(this).attr('id');
        var url='<?php echo e(route("admin_teacher.show",":id")); ?>';
        var url = url.replace(':id', id);
        // edit
         $.ajax({
            url:url,
            type:'GET',
            dataType:'json',
            success:function(data){
               $('.view_student_name').html(data.name);
               $('.view_student_email').html(data.email);
               $('.view_s_phone').html(data.phone);
               if(data.status == 1){
               $('.view_status').html('Active');
               }else{
               $('.view_status').html('Deactive');
               }
            }
        });
      });
  </script>


       <?php $__env->stopSection(); ?>

      <?php $__env->stopSection(); ?>

      
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\bp\local\resources\views/backend/admin_teacher.blade.php ENDPATH**/ ?>