@extends('layouts.frontend')

@section('content')


       <!-- registration-area -->
        <section class="registration-area wow fadeInDown">
            <div class="container">
                <div class="row">
                    <div class="registration mtb">
                        <h2>login</h2>
                        <form action="{{ route('login') }}" method="POST">
                            @csrf
                          <div class="form-group row">
                            <label for="email" class="col-sm-2 col-form-label">Email</label>
                            <div class="col-sm-10">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                          </div>
                          <div class="form-group row">
                            <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
                            <div class="col-sm-10">
                              <input type="password" class="form-control @error('password') is-invalid @enderror" name="password" id="inputPassword" placeholder="Password" autocomplete="current-password">
                              @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                          </div>
                          <div class="form-check form_check">
                              <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                              <label class="form-check-label" for="remember">
                                Remember Me
                              </label>
                               @if (Route::has('password.request'))
                              <a href="{{ route('password.request') }}">forgot password?</a>
                               @endif
                          </div>
                          <div class="regis_button">
                            <button>sign in</button>
                            <p>don't have an account <a href="{{route('register')}}">Registration</a></p>
                          </div>
                        </form>
                    </div>
                </div>
            </div>
        </section><!-- registration-area end -->














@endsection
