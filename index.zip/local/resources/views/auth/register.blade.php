@extends('layouts.frontend')

@section('content')
<?php $user_roles = DB::table('user_roles')->where('id', 1)->orwhere('id',2)->orwhere('id',3)->get();?>
    <!-- registration-area -->
        <section class="registration-area">
            <div class="container">
                <div class="row">
                    <div class="registration mtb">
                        <h2>registration</h2>
                        <form  action="{{ route('register') }}" method="POST">
                            @csrf
                          <div class="form_option">
                           <select class="form-control" id="gender1" name="role" required>
                              <option value="">Select Role</option>
                             @foreach($user_roles as $roles)
                               <option value="{{$roles->id}}">{{$roles->role_name}}</option>
                             @endforeach
                           </select>
                          </div>
                          <div class="form-group row">
                            <label for="name" class="col-sm-3 col-form-label">Name</label>
                            <div class="col-sm-9">
                              <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>
                               @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror

                            </div>
                          </div>
                          <div class="form-group row">
                            <label for="email" class="col-sm-3 col-form-label">Email</label>
                            <div class="col-sm-9">
                           <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">
                           @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                           @enderror

                            </div>
                          </div>   
                         <div class="form-group row">
                            <label for="phone" class="col-sm-3 col-form-label">Phone</label>
                            <div class="col-sm-9">
                           <input id="phone" type="text" class="form-control @error('phone') is-invalid @enderror" name="phone" value="{{ old('phone') }}" required autocomplete="phone">
                           @error('phone')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                           @enderror

                            </div>
                          </div>
                          <div class="form-group row">
                            <label for="password" class="col-sm-3 col-form-label">Password</label>
                            <div class="col-sm-9">
                              <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">
                              @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                          </div>

                          <div class="form-group row">
                            <label for="repeatpass" class="col-sm-3 col-form-label">Repeat Pass</label>
                            <div class="col-sm-9">
                               <input id="repeatpass" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                          </div>
                          <div class="regis_button">
                            <button>registration</button>
                            <p>already have a account <a href="{{route('login')}}">Sign in</a></p>
                          </div>
                        </form>
                    </div>
                </div>
            </div>
        </section><!-- registration-area end -->
        <!-- footer-area -->
















@endsection
