
@extends('layouts.frontend')
@section('content')
	<!-- start home_search_area -->
	<section class="home_search_area">
		<div class="container">
			<div class="row">
				<div class="advence_search mtb">
					<img src="{{asset('local/public/contents/frontend')}}/images/logof.png" alt="logo">
					<div class="logob">
						<img src="{{asset('local/public/contents/frontend')}}/images/bpteacher.png" class="img-fluid">
					</div>
					<form action="{{route('search_result')}}">
						<div class="form-group form_pad">
						      <input type="search" class="form-control" id="name" placeholder="Search...">
						</div>
						<div class="class_click">
							  <a href="#" id="clickk">advanced serach</a>
						</div>
						<div class="serach_options">
							<div class="row">
								<select class="form-control option1">
								  	<option value="">Select District&hellip;</option>
								    <option value="january">Dhaka</option>
								    <option value="february">Pabna</option>
								</select>
								<select class="form-control option1">
								   	<option value="">Police Station&hellip;</option>
								    <option value="january">Dhaka</option>
								    <option value="february">Pabna</option>
								</select>
								<select class="form-control option1">
								  	<option value="">Select Area&hellip;</option>
								    <option value="january">Dhaka</option>
								    <option value="february">Pabna</option>
								</select>
								<select class="form-control option1">
								  	<option value="">Exam Board&hellip;</option>
								    <option value="january">Dhaka</option>
								    <option value="february">Pabna</option>
								</select>
								<select class="form-control option1">
								  	<option value="">Select Level&hellip;</option>
								    <option value="january">Level1</option>
								    <option value="february">Level2</option>
								</select>
								<select class="form-control option1">
								  	<option value="">Select Subject&hellip;</option>
								    <option value="january">Benglai</option>
								    <option value="february">English</option>
								</select>
							</div>
						</div>
						<div class="regis_button">
						  	<button>search</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</section>
@endsection