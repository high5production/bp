@extends('layouts.frontend')
@section('content')


		<!-- subject-area -->
		<section class="subject-area" style="height: 100%">
			<div class="container">
				<div class="row">
					@include('frontend.template-parts.teacher_sidebar')
					<div class="sub-content sub-content2 col-md-10 wow fadeInDown">
						<div class="row">
						<nav style="width: 100%">
							<div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
								<a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Type</a>
								<a class="nav-item nav-link" id="nav-home-tab" data-toggle="tab" href="#nav-homee" role="tab" aria-controls="nav-home" aria-selected="true">Personal</a>
								<a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Profile</a>
								<a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Contact</a>
								<a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#nav-about" role="tab" aria-controls="nav-about" aria-selected="false">Profession</a>
								<a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#tab6" role="tab" aria-controls="nav-about" aria-selected="false">Class</a>
								<a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#tab7" role="tab" aria-controls="nav-about" aria-selected="false">Education</a>
								<a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#tab8" role="tab" aria-controls="nav-about" aria-selected="false">Place</a>
								<a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#tab9" role="tab" aria-controls="nav-about" aria-selected="false">Coaching</a>
								<a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#tab100" role="tab" aria-controls="nav-about" aria-selected="false">About</a>
								<a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#tab11" role="tab" aria-controls="nav-about" aria-selected="false">Training</a>
							</div>
						</nav>
						</div>



						<div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
							<div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
							<form action="{{route('teacher.update',$profile_id)}}" method="post">
								@csrf
								@method('put')

								<div class="tab_options">
									<h4>teacher type</h4>
									<div class="checkboxx">
									  <input class="form-check-input" name="type" type="checkbox" value="school teacher"  id="defaultCheck1" {{'school teacher' == $teacher_info->type ? 'checked': ''}}>
									  <label class="form-check-label" for="defaultCheck1">
									    School Teacher
									  </label>
									</div>
									<div class="checkboxx">
									   <input class="form-check-input" name="type" value="freelance teacher" type="checkbox" id="defaultCheck2" {{'freelance teacher' == $teacher_info->type ? 'checked': ''}}>
									  <label class="form-check-label" for="defaultCheck2">
									    Freelance Teacher
									  </label>
									</div>
									<div class="checkboxx">
									   <input class="form-check-input" value="house tutor" name="type" type="checkbox" id="defaultCheck3" {{'house tutor' == $teacher_info->type ? 'checked': ''}}>
									  <label class="form-check-label" for="defaultCheck3">
									    House Tutor
									  </label>
									</div>

									<div class="checkboxx">
									   <input class="form-check-input" value="all" name="type" type="checkbox" id="ff" {{'all' == $teacher_info->type ? 'checked': ''}}>
									  <label class="form-check-label" for="ff">
									    All
									  </label>
									</div>
									
									<div class="regis_button tab_sub">
									  	<button>submit</button>
									</div>
								</div>
								</form>
							</div>




							<div class="tab-pane fade" id="nav-homee" role="tabpanel" aria-labelledby="nav-home-tab">
					            @include('frontend.template-parts.tabs.personal')
							</div>




							<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
								<form action="{{route('teacher.update',$profile_id)}}" method="post">
								 @csrf;
								 @method('PUT')
								<div class="infr_adress">
									<h4>adress</h4>
									<div class="form-group row">
									    <label for="house" class="col-sm-3 col-form-label">House Adress</label>
									    <div class="col-sm-9">
									      <textarea class="form-control" id="house" placeholder="House,Lane,Road" name="address">{{$teacher_info->address}}</textarea>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="area" class="col-sm-3 col-form-label">Area</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="area" placeholder="Area" name="area" value="{{$teacher_info->area}}">
									    </div>
									</div>
									
									<div class="form-group tab_select row">
										<label class="col-sm-3">Select City</label>
										<div class="col-sm-9">
											<select id="selectboxx" name="city">
											    <option value="">Select City</option>
											    <option value="Dhaka" {{$teacher_info->city == 'Dhaka' ? 'selected' : ''}}>Dhaka</option>
											    <option value="Pabna" {{$teacher_info->city == 'Pabna' ? 'selected' : ''}}>Pabna</option>
											     <option value="Borisal" {{$teacher_info->city == 'Borisal' ? 'selected' : ''}}>Borisal</option> 
											     <option value="Rangpur" {{$teacher_info->city == 'Rangpur' ? 'selected' : ''}}>Rangpur</option> 
											     <option value="Kulna" {{$teacher_info->city == 'Kulna' ? 'selected' : ''}}>Kulna</option>
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">Police Station</label>
										<div class="col-sm-9">
											<select id="selectboxx" name="police_station" required>
											    <option value="">Police Station</option>
											      @foreach($get_police_station as $police_station)
											       <option value="{{$police_station->id}}" {{$police_station->id == $teacher_info->police_station ? 'selected' : ''}}>{{$police_station->police_station}}</option>
											      @endforeach
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">Select District</label>
										<div class="col-sm-9">
											<select id="selectboxx" name="district">
											    <option value="">Select District</option>
											    @foreach($getdis as $dis)
											       <option value="{{$dis->id}}" {{$dis->id == $teacher_info->district ? 'selected' : '' }}>{{$dis->district_name}}</option>
											     @endforeach
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">Select Country</label>
										<div class="col-sm-9">
											<select id="selectboxx" name="country">
											    <option value="">Select Country</option>
											     @foreach($allcountry as $country)
											       <option value="{{$country->id}}" {{$country->id == $teacher_info->country ? 'selected' : ''}}>{{$country->country_name}}</option>
											     @endforeach
											</select>
										</div>
									</div>
									<div class="regis_button tab_sub">
									  	<button>submit</button>
									</div>
								</div>
								</form>
							</div>




							<div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
								<form action="{{route('teacher.update',$profile_id)}}" method="post">
								@csrf
								@method('put')
								 <div class="infr_adress">
									<h4>Contact</h4>
									<div class="form-group row">
									    <label for="c_contact" class="col-sm-3 col-form-label">Phone</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="c_contact" placeholder="Personal Contact Number" value="{{$teacher_info->phone}}" name="phone" required>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="email" class="col-sm-3 col-form-label">Email</label>
									    <div class="col-sm-9">
									      <input type="email" class="form-control" id="email" placeholder="Email" value="{{$teacher_info->email}}" name="email" required>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="website" class="col-sm-3 col-form-label">Website</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="website" placeholder="Website Link" value="{{$teacher_info->email}}" name="website" required>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="c_facebook" class="col-sm-3 col-form-label">Facebook</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="c_facebook" placeholder="Facebook" value="{{$teacher_info->facebook}}" name="facebook" required>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="c_twitter" class="col-sm-3 col-form-label">Twitter</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="c_twitter" placeholder="Twitter" name="twitter" value="{{$teacher_info->twitter}}" required>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="c_link" class="col-sm-3 col-form-label">Other Link</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="c_link" placeholder="Other Links" name="other_link" value="{{$teacher_info->other_link}}" required>
									    </div>
									</div>
									<div class="regis_button tab_sub">
									  	<button>submit</button>
									</div>
								</div>
							   </form>
							</div>



							<div class="tab-pane fade" id="nav-about" role="tabpanel" aria-labelledby="nav-about-tab">
						        @include('frontend.template-parts.tabs.teacher_profession')
							</div>




							<div class="tab-pane fade" id="tab6" role="tabpanel" aria-labelledby="nav-about-tab">
							<form action="{{route('teacher.update',$profile_id)}}" method="post" enctype="multipart/form-data">
								@csrf
								@method('put')
								<div class="infr_adress">
									<h4>class management information</h4>
									<div class="form-group">
										<label for="count">How many students in every batch? </label>
										<input type="text" placeholder="Number of students" id="count" class="form-control" name="total_student" value="{{$teacher_info->total_student}}">
									</div>
									<div class="form-group form_color">
										<label for="routine">Complete Routine(.docx, .pdf, .jpg, .png) </label>
										<input type="file" placeholder="Upload Routine" id="routine" name="routine" value="{{$teacher_info->routine}}">
									</div>
									<div class="form-group">
										<label for="office_n">Office Contact Number</label>
										<input type="text" placeholder="Office Contact Number" id="office_n" class="form-control" name="office_contact_number" value="{{$teacher_info->office_contact_number}}">
									</div>
									<div class="regis_button tab_sub">
									  	<button>submit</button>
									</div>
								</div>
							   </form>
							</div>
							<div class="tab-pane fade" id="tab7" role="tabpanel" aria-labelledby="nav-about-tab">
								 @include('frontend.template-parts.tabs.teacher_education')
							</div>




							<div class="tab-pane fade" id="tab8" role="tabpanel" aria-labelledby="nav-about-tab">

                               @include('frontend.template-parts.tabs.teacher_coaching')

							</div>
							<div class="tab-pane fade" id="tab9" role="tabpanel" aria-labelledby="nav-about-tab">
							  <form action="{{route('teacher.update', $profile_id)}}" method="post">
								@csrf
								@method('put')
								<div class="infr_adress">
									<h4>attached coaching place</h4>
									<div class="form-group">
										<label for="esta">When did the coaching centre was established?</label>
										<input type="text" placeholder="Established Time" id="esta" class="form-control datepicker_cp" name="coaching_establish_date" value="{{$teacher_info->coaching_establish_date}}" autocomplete="off" required>
									</div>
									<div class="form-group">
										<label for="taught">What other subjects taught there</label>
										<input type="text" placeholder="Other Subjects taught there" id="taught" class="form-control" name="other_subject" value="{{$teacher_info->other_subject}}" required>
									</div>
									<div class="regis_button tab_sub">
									  	<button>save</button>
									</div>
								</div>
								</form>
							</div>
							<div class="tab-pane fade" id="tab100" role="tabpanel" aria-labelledby="nav-about-tab">
							
							<form action="{{route('teacher.update',$profile_id)}}" method="post">
								@csrf
								@method('put')
								<div class="infr_adress">
									<h4>about myself</h4>
										<div class="form-group">
											<label for="about">About Myself</label>
											<textarea class="form-control" id="about" placeholder="A 250 words text about the teacher himself" name="about" rows="15" required>{{$teacher_info->about}}</textarea>
										</div>
										<div class="regis_button tab_sub">
										  	<button>save</button>
										</div>
								</div>
								</form>
							</div>
							<div class="tab-pane fade" id="tab11" role="tabpanel" aria-labelledby="nav-about-tab">
							   <!-- traning tab -->
							     @include('frontend.template-parts.tabs.teacher_traning')
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

@endsection