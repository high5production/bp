@extends('layouts.frontend')
@section('content')
	

	<!-- subject-area -->
	<section class="subject-area search_resultt">
		<div class="container">
			<div class="row">
				@include('frontend.template-parts.search-result-sidebar')
				<div class="sub-content scroll col-md-9">
					<h2>search result</h2>
					<!-- sub_content_single-->

                    @foreach($all_t_profile as $search_profile)
					<div class="sub_content_single">
						<div class="sub_con_img">
							@if($search_profile->photo != 'noimage.jpg')
								<img src="{{asset('local/public/contents/upload/teacher/profile')}}/{{$search_profile->photo}}">
							@else
							 <img src="{{asset('local/public/contents/frontend/images/noimage.jpg')}}" alt="image">
							@endif
							<div class="teacher_id">
								<h4>2255</h4>
							</div>
						</div>
						<div class="sub_con2">
							<div class="sub_name">
								<h5>{{$search_profile->name}}</h5>
								<h5>physics</h5>
								<h5>{{$search_profile->teaching_level}}</h5>
								<h5>{{$search_profile->phone}}</h5>
								<ul>
									<li><a href="{{$search_profile->facebook}}"><i class="fa fa-facebook"></i></a></li>
									<li><a href="{{$search_profile->twitter}}"><i class="fa fa-twitter"></i></a></li>
								</ul>
							</div>
							<div class="sub_con_text">
								<p>{!! Str::words($search_profile->about, 45,'....')  !!}<a href="{{route('teacher_profile',$search_profile->id)}}">More Details</a></p>
							</div>
							<div class="teacher_id">
								<h4>2255</h4>
							</div>
						</div>
					</div>
					@endforeach
				
				</div>
			</div>
		</div>
	</section>
	<!-- subject-area end -->
@endsection