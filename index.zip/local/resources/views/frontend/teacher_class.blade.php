@extends('layouts.frontend')
@section('content')
		<!-- subject-area -->
		<section class="subject-area sub_height">
			<div class="container">
				<div class="row">
					@include('frontend.template-parts.teacher_sidebar')
					<div class="sub-content sub_contett sub-content2 col-md-10">
						<div class="row">
							<div class="subscription_area">
								<h4>upload class routine</h4>
								<form>
									<div class="form-group row routinem">
									    <label for="slip" class="col-sm-4 col-form-label">Upload Routine(.docx, .pdf, .jpg, .png)</label>
									    <div class="col-sm-8">
									      <input type="file" id="slip" placeholder="Bank Payment Slip" >
									    </div>
									</div>
									<div class="regis_button tab_sub">
									  	<button>submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

@endsection