@extends('layouts.frontend')
@section('content')

		<!-- subject-area -->
		<section class="subject-area sub_height">
			<div class="container">
				<div class="row">
				@include('frontend.template-parts.teacher_sidebar')
					<div class="sub-content sub-content2 col-md-10 wow fadeInDown">
						<div class="row">
						<nav id="navv">
							<div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
								<a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">New Notice</a>
								<a class="nav-item nav-link" id="nav-home-tab" data-toggle="tab" href="#nav-homee" role="tab" aria-controls="nav-home" aria-selected="true">All Notice</a>
								<a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Comment</a>
							</div>
						</nav>
						</div>
						<div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
							<div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
								<div class="notice">
									<h4>write a new notice</h4>
									<div class="form-group">
										<label for="notice_title">Notice Title</label>
										<input type="text" id="notice_title" class="form-control" name="" placeholder="Add Your Notice Title">
									</div>
									<div class="form-group">
										<label for="notice">Notice Body</label>
										<textarea class="form-control" id="notice" placeholder="Write a Notice"></textarea>
									</div>
									<ul>
										<li><button>Save as Draft</button></li>
										<li><button>Publish</button></li>
									</ul>
								</div>
							</div>
							<div class="tab-pane fade" id="nav-homee" role="tabpanel" aria-labelledby="nav-home-tab">
								<div class="notice_all">
									<h4>all notice</h4>
									<div class="notice_single">
										<a href="student_notice.html">
											<h5>Notice Title here</h5>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Laelius clamores sofòw ille so lebat Edere compellans gumias ex ordine nostros. Itaque hic ipse iam pridem est reiectus; Lorem ipsum dolor sit amet, consectetur adipisci</p>
										</a>
									</div>
									<div class="notice_single">
										<a href="student_notice.html">
											<h5>Notice Title here</h5>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Laelius clamores sofòw ille so lebat Edere compellans gumias ex ordine nostros. Itaque hic ipse iam pridem est reiectus; Lorem ipsum dolor sit amet, consectetur adipisci</p>
										</a>
									</div>
									<div class="notice_single">
										<a href="student_notice.html">
											<h5>Notice Title here</h5>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Laelius clamores sofòw ille so lebat Edere compellans gumias ex ordine nostros. Itaque hic ipse iam pridem est reiectus; Lorem ipsum dolor sit amet, consectetur adipisci</p>
										</a>
									</div>
								</div>
							</div>
							<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
								<div class="infr_adress all_comment">
									<h4>All Comment</h4>
									<div class="single_comment">
										<p><span id="title_bold">Notice title:</span> First Notice </p>
										<p><span id="title_bold">Comment:</span> Thanks Sir for notice</p>
										<ul>
											<li><a href="#">approve</a></li>
											<li><a href="#">reply</a></li>
											<li><a href="#">edit</a></li>
											<li><a href="#">trash</a></li>
										</ul>
									</div>
									<div class="single_comment">
										<p><span id="title_bold">Notice title:</span> Second Notice </p>
										<p><span id="title_bold">Comment:</span> Thanks Sir for notice</p>
										<ul>
											<li><a href="#">approve</a></li>
											<li><a href="#">reply</a></li>
											<li><a href="#">edit</a></li>
											<li><a href="#">trash</a></li>
										</ul>
									</div>
									<div class="single_comment">
										<p><span id="title_bold">Notice title:</span> Third Notice </p>
										<p><span id="title_bold">Comment:</span> Thanks Sir for notice</p>
										<ul>
											<li><a href="#">approve</a></li>
											<li><a href="#">reply</a></li>
											<li><a href="#">edit</a></li>
											<li><a href="#">trash</a></li>
										</ul>
									</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</section>


	@endsection