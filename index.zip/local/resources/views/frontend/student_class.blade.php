@extends('layouts.frontend')
@section('content')

		<!-- subject-area -->
		<section class="subject-area sub_height">
			<div class="container">
				<div class="row">
					@include('frontend.template-parts.student_sidebar')
					<div class="sub-content sub-content2 col-md-10">
						<div class="row">
							<div class="subscription_area">
								<h4>student class routine</h4>
								<img src="{{asset('local/public/contents/frontend')}}/images/routine.jpg" alt="image">
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>


		@endsection