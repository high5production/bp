	<form action="{{route('teacher.update',$profile_id)}}" method="post">
								@csrf
								@method('put')
								<div class="infr_adress">
									<h4>Profession</h4>
									<div class="form-group tab_select row">
										<label class="col-sm-3">Teaching Level</label>
										<div class="col-sm-9">
											<select id="selectboxx" name="teaching_level" required>
											    <option value="">Teaching Level...</option>
											    <option value="O Level" {{ "O Level" == $teacher_info->teaching_level ? 'selected' : ''}}>O Level</option>
											    <option value="A Level" {{ "A Level" == $teacher_info->teaching_level ? 'selected' : ''}}>A Level</option>
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">Teaching Class</label>
										<div class="col-sm-9">
											<select id="selectboxx" name="teaching_class" required>
											    <option value="">Teaching Class</option>
											     @foreach($allclass as $class)
											     <option value="{{$class->id}}" {{$class->id == $teacher_info->teaching_class ? 'selected' : ''}}>{{$class->class_name}}</option>
											     @endforeach
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">Teaching Subject</label>
										<div class="col-sm-9">
											<select id="selectboxx" name="teaching_subject" required>
											    <option value="">Teaching Subject</option>
											     @foreach($allsubjects as $getsub)
											      <option value="{{$getsub->id}}" {{$getsub->id== $teacher_info->teaching_subject ? 'selected' : ''}}>{{$getsub->subject_name}}</option>
											     @endforeach
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">Teaching Since</label>
										<div class="col-sm-9">
											<select id="selectboxx" name="teaching_since" required>
											    <option value="">Teaching Since</option>
											    <option value="1990" {{1990== $teacher_info->teaching_since ? 'selected' : ''}}>1990</option>
											    <option value="1991" {{1991== $teacher_info->teaching_since ? 'selected' : ''}}>1991</option>
											    <option value="1992" {{1992== $teacher_info->teaching_since ? 'selected' : ''}}>1992</option>
											    <option value="1993" {{1993== $teacher_info->teaching_since ? 'selected' : ''}}>1993</option>
											    <option value="1994" {{1994== $teacher_info->teaching_since ? 'selected' : ''}}>1994</option>
											    <option value="1995" {{1995== $teacher_info->teaching_since ? 'selected' : ''}}>1995</option>
											    <option value="1996" {{1996== $teacher_info->teaching_since ? 'selected' : ''}}>1996</option>
											    <option value="1997" {{1997== $teacher_info->teaching_since ? 'selected' : ''}}>1997</option>
											    <option value="1998" {{1998== $teacher_info->teaching_since ? 'selected' : ''}}>1998</option>
											    <option value="1999" {{1999== $teacher_info->teaching_since ? 'selected' : ''}}>1999</option>
											    <option value="2000" {{2000== $teacher_info->teaching_since ? 'selected' : ''}}>2000</option>
											    <option value="2001" {{2001== $teacher_info->teaching_since ? 'selected' : ''}}>2001</option>
											    <option value="2002" {{2002== $teacher_info->teaching_since ? 'selected' : ''}}>2002</option>
											    <option value="2003" {{2003== $teacher_info->teaching_since ? 'selected' : ''}}>2003</option>
											    <option value="2004" {{2004== $teacher_info->teaching_since ? 'selected' : ''}}>2004</option>
											    <option value="2005" {{2005== $teacher_info->teaching_since ? 'selected' : ''}}>2005</option>
											    <option value="2006" {{2006== $teacher_info->teaching_since ? 'selected' : ''}}>2006</option>
											    <option value="2007" {{2007== $teacher_info->teaching_since ? 'selected' : ''}}>2007</option>
											    <option value="2008" {{2008== $teacher_info->teaching_since ? 'selected' : ''}}>2008</option>
											    <option value="2009" {{2009== $teacher_info->teaching_since ? 'selected' : ''}}>2009</option>
											    <option value="2010" {{2010== $teacher_info->teaching_since ? 'selected' : ''}}>2010</option>
											    <option value="2011" {{2011== $teacher_info->teaching_since ? 'selected' : ''}}>2011</option>
											    <option value="2012" {{2012== $teacher_info->teaching_since ? 'selected' : ''}}>2012</option>
											    <option value="2013" {{2013== $teacher_info->teaching_since ? 'selected' : ''}}>2013</option>
											    <option value="2014" {{2014== $teacher_info->teaching_since ? 'selected' : ''}}>2014</option>
											    <option value="2015" {{2015== $teacher_info->teaching_since ? 'selected' : ''}}>2015</option>
											    <option value="2016" {{2016== $teacher_info->teaching_since ? 'selected' : ''}}>2016</option>
											    <option value="2019" {{2019== $teacher_info->teaching_since ? 'selected' : ''}}>2017</option>
											    <option value="2019" {{2019== $teacher_info->teaching_since ? 'selected' : ''}}>2018</option>
											    <option value="2019" {{2019== $teacher_info->teaching_since ? 'selected' : ''}}>2019</option>
											</select>
										</div>
									</div>
									<div class="present_school">
										<h4>present school</h4>
										<div class="row">
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="p_school">Present School</label>
												    <input type="text" name="present_school" class="form-control" id="p_school" placeholder="Present School" value="{{$teacher_info->present_school }}" required>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="j_date">Joining Date</label>
												    <input type="date" class="form-control datepicker_cp" id="j_date" placeholder="Joining Date" value="{{$teacher_info->present_joining_date}}" name="present_joining_date" required>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="p_posi">Position</label>
												    <input type="text" class="form-control" id="p_posi" placeholder="Present Position" value="{{$teacher_info->present_position}}" name="present_position" required>
												</div>
											</div>
										</div>
									</div>
									<div class="present_school">
										<h4>last school</h4>
										<div class="row">
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="l_school">Last School</label>
												    <input type="text" class="form-control" id="l_school" placeholder="Last School" name="last_school" value="{{$teacher_info->last_school}}" required>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="l_date">Till Date</label>
												    <input type="date" class="form-control datepicker_cp" id="l_date" placeholder="Till the date worked" name="last_joning_date" value="{{$teacher_info->last_joning_date}}" required>
												</div>
											</div>
											<div class="col-sm-4">
												<div class="form-group">
												    <label for="l_posi">Position</label>
												    <input type="text" class="form-control" id="l_posi" placeholder="Present Position" name="last_position" value="{{$teacher_info->last_position}}" required>
												</div>
											</div>
										</div>
									</div>
									<div class="regis_button tab_sub">
									  	<button>submit</button>
									</div>
								</div>
								</form>