		<form action="{{route('teacher.update',$profile_id)}}" method="post" enctype="multipart/form-data">
								@csrf
								@method('put')
								<div class="personal">


									<div class="form-group row">
									    <label for="name" class="col-sm-3 col-form-label">Upload Your Image</label>
									    <div class="col-sm-9">
									    

										<div class="drop">
										  <div class="uploader">
										    <label class="drop-label">Drag and drop images here</label>
										    <input type="file" class="image-upload" id="photo" name="photo" accept="image/*" value="{{$teacher_info->photo}}">
										  </div>
										  <div id="image-preview">
										  	@if($teacher_info->photo != 'noimage.jpg')
										  	<img src="{{asset('local/public/contents/upload/teacher/profile')}}/{{$teacher_info->photo}}">
										  	@endif

										  </div>
										</div>



									    </div>
									</div>


									<div class="form-group row">
									    <label for="name" class="col-sm-3 col-form-label">Name</label>
									    <div class="col-sm-9">
									      <input type="text" name="name" class="form-control" id="name" placeholder="name" value="{{$teacher_info->name}}" required>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="Initial" name="init_name" class="col-sm-3 col-form-label">Intial</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="Initial" placeholder="Initial" name="init_name" value="{{$teacher_info->init_name}}" required>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="birth" class="col-sm-3 col-form-label">Dath of Birth</label>
									    <div class="col-sm-9">
									      <input type="date" name="birth_date" class="form-control datepicker_cp" id="birth" placeholder="Date of Birth" value="{{$teacher_info->birth_date}}" required>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="birth" class="col-sm-3 col-form-label">Gender</label>
									    <div class="col-sm-9">
									       <select name="gender" class="form-control" required>
									       	  <option value="">Select Gender</option>
									       	  <option value="male" {{'male' == $teacher_info->gender ? 'selected' : ''}}>Male</option>
									       	  <option value="female" {{'female' == $teacher_info->gender ? 'selected' : ''}}>Feame</option>
									       	  <option value="other" {{'other' == $teacher_info->gender ? 'selected' : ''}}>Other</option>
									       </select>
									    </div>
									</div>
									<div class="regis_button tab_sub">
									  	<button>submit</button>
									</div>
								</div>
							    </form>













							    <style type="text/css">  



.drop { background-color: #fff; }

.drop:after { border: dashed 0.3rem rgba(0, 0, 0, 0.0875); }

.drop .drop-label { color: rgba(0, 0, 0, 0.0875); }

.drop:hover:after { border-color: rgba(0, 0, 0, 0.125); }

.drop:hover .drop-label { color: rgba(0, 0, 0, 0.125); }

#image-preview, .image-preview { background-color: #000; }

.drop {
    width: 100px;
    height: 80px;
    position: relative;
    overflow: hidden;
    cursor: pointer;
    margin: 0;
}
.drop:after {
  content: "";
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  bottom: 0;
}

.drop.file-focus { border: 0; }

.drop:hover { cursor: pointer; }

.drop .drop-label {
    font-size: 9px;
    font-weight: 300;
    line-height: 4rem;
    width: 32rem;
    text-align: center;
    position: absolute;
    top: 50%;
    margin-top: -1.5rem;
    left: 50%;
    margin-left: -16rem;
    color: #000;
}
.drop input[type=file] {
  line-height: 50rem;
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  height: 100%;
  width: 100%;
  opacity: 0;
  z-index: 10;
  cursor: pointer;
}

#image-preview, .image-preview {
  width: 100%;
  display: block;
  position: relative;
  z-index: 1;
}

#image-preview:empty, .image-preview:empty { display: none; }

#image-preview img, .image-preview img {
  display: block;
  margin: 0 auto;
  width: 100%
}

#image-preview:after, .image-preview:after {
  content: "";
  position: absolute;
  top: 0;
  bottom: 0;
  right: 0;
  left: 0;
  border: solid 0.1rem rgba(0, 0, 0, 0.08);
  background: bottom center repeat-x url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAABfCAMAAAAeT108AAABEVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABoX7lMAAAAW3RSTlMBCHwGAwQFCgIMCw4PERITFBYXGRoNHR4gISIlJicpKiwuLzEzNDY3OTs8G0BBQ0VGSEpLTU9QUVRVVlhZW11eX2FiZGVmaGlrbG1ucHFyc3R1dnd4eXp7Pn1+eLXrxAAAADRJREFUCFtjYAACDmYGJkYmRiDJAMJMbEzMTP+ZeJgZmTChOFZR7FAPYi71IQMT0JXhTIwAN8YCxDyw89IAAAAASUVORK5CYII=);
}




							    </style>