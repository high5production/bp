<div class="sub-head sub_head22 col-md-2 wow fadeInDown">
	<h2>teacher information</h2>
	<ul>
		<li><a href="{{route('teacher_deshboard')}}">profile</a></li>
		<li><a href="{{route('teacher_subscription')}}">subscription fee</a></li>
		<li><a href="{{route('teacher_class')}}">class</a></li>
		<li><a href="{{route('teacher_notice')}}">notice</a></li>
	</ul>
</div>