
<?php 
use App\Models\admin_subject;
 $getdata = admin_subject::where('status',1)->get();
?>
             <div class="sub-head scroll col-md-3 wow fadeInDown" id="sub_border">
					<h2>subject</h2>
					<ul>
						@foreach($getdata as $data)
						<li><a href="#" data-toggle="tooltip" data-placement="top" title="{{$data->boardname->board_name}}">{{$data->subject_name}}<span class="board_color" style="background:{{$data->boardname->board_color}}"></span></a></li>
						@endforeach
						
					</ul>
				</div>