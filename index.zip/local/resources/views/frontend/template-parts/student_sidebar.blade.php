<div class="sub-head sub_head22 col-md-2 wow fadeInDown">
	<h2>student information</h2>
	<ul>
		<li><a href="{{route('student_deshboard')}}">personal info</a></li>
		<li><a href="{{route('student_class')}}">class</a></li>
		<li><a href="{{route('student_notice')}}">notice</a></li>
	</ul>
</div>