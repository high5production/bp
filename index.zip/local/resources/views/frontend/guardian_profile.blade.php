@extends('layouts.frontend')
@section('content')

		<!-- subject-area -->
		<section class="subject-area">
			<div class="container">
				<div class="row">
						@include('frontend.template-parts.guardian_sidebar')
					<div class="sub-content sub-content2 col-md-10 wow fadeInDown">
						<div class="row">
						<nav id="navv">
							<div class="nav nav-tabs nav-fill active" id="nav-tab" role="tablist">
								<a class="nav-item nav-link" id="nav-codepopular-tab" data-toggle="tab" href="#nav-codepopular" role="tab" aria-controls="nav-codepopular" aria-selected="true">Gurdian One</a>
								<a class="nav-item nav-link" id="nav-home-tab" data-toggle="tab" href="#nav-homee" role="tab" aria-controls="nav-home" aria-selected="true">Gurdian Two</a>
								<a class="nav-item nav-link" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Student Info</a>
								
							</div>
						</nav>
						</div>
						<div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
						
							  <!-- Guardian one -->
								<div class="tab-pane fade show active" id="nav-codepopular" role="tabpanel" aria-labelledby="nav-codepopular-tab">
										<form action="{{route('guardian.update',$profile_id)}}" method="post">
										@csrf
										@method('put')
								<div class="student_inform">
									<h4>Guardian One</h4>
									<div class="form-group row">
									    <label for="f_name" class="col-sm-3 col-form-label">Guardian Name</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="f_name" placeholder="Guardian Name" name="g1_name" value="{{$g_profile->g1_name}}">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="g_number" class="col-sm-3 col-form-label">Contact Number</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="g_number" placeholder="Enter contact no" name="g1_phone" value="">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="g_realtion" class="col-sm-3 col-form-label">Relationship with student</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="g_realtion" placeholder="Relationship with student" name="g1_relation">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="g_email" class="col-sm-3 col-form-label">Email</label>
									    <div class="col-sm-9">
									      <input type="email" class="form-control" id="g_email" placeholder="Email Address" name="g1_email">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_address" class="col-sm-3 col-form-label">Address</label>
									    <div class="col-sm-9">
									      <textarea class="form-control" id="f_address" placeholder=" House Name, House, Flat, Road, Police Station" autocomplete="off" name="g_address" name="g1_address"></textarea>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_profession" class="col-sm-3 col-form-label">Profession</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="f_profession" placeholder="Profession" name="g_profession" name="g1_profession">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_nid" class="col-sm-3 col-form-label">NID</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="f_nid" placeholder="NID Number" name="g1_nid">
									    </div>
									</div>
								
									<div class="form-group tab_select row">
										<label class="col-sm-3">Area</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="g1_area">
											    <option value="">Select Area..</option>
											    <option value="january">Dhaka</option>
											    <option value="february">Pabna</option>
											</select>
										</div>
									</div>	
									<div class="form-group tab_select row">
										<label class="col-sm-3">Police Station</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="g1_ps_id">
											    <option value="">Select Police Station..</option>
											    <option value="january">Dhaka</option>
											    <option value="february">Pabna</option>
											</select>
									 </div>

									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">City</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="g1_city">
											    <option value="">Select City..</option>
											    <option value="january">Dhaka</option>
											    <option value="february">Pabna</option>
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">District</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="g1_district">
											    <option value="">Select District..</option>
											    <option value="january">Dhaka</option>
											    <option value="february">Pabna</option>
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">Country</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="g1_country">
											    <option value="">Select Country..</option>
											    <option value="january">Mohammadpur</option>
											    <option value="february">Uttara</option>
											</select>
										</div>
									</div>
									<div class="regis_button tab_sub">
									  	<button>save</button>
									</div>
								</div>
							</form>
							</div>

                                <!-- guardina two -->
						<div class="tab-pane fade" id="nav-homee" role="tabpanel" aria-labelledby="nav-home-tab">
							<form action="#" method="post">
								@csrf
								@method('put')
								<div class="student_inform">
									<h4>Guardian Two</h4>
									<div class="form-group row">
									    <label for="g2_name" class="col-sm-3 col-form-label">Guardian Name</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="g2_name" placeholder="Guardian Name" name="g2_name">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="g_number" class="col-sm-3 col-form-label">Contact Number</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="g_number" placeholder="Enter contact no" name="g2_phone">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="g_realtion" class="col-sm-3 col-form-label">Relationship with student</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="g_realtion" placeholder="Relationship with student" name="g2_relation">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="g2_email" class="col-sm-3 col-form-label">Email</label>
									    <div class="col-sm-9">
									      <input type="email" class="form-control" id="g2_email" placeholder="Email Address" name="g2_email">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="g2_address" class="col-sm-3 col-form-label">Address</label>
									    <div class="col-sm-9">
									      <textarea class="form-control" id="g2_address" placeholder=" House Name, House, Flat, Road, Police Station" autocomplete="off" name="g_address" name="g2_address"></textarea>
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_profession" class="col-sm-3 col-form-label">Profession</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="f_profession" placeholder="Profession" name="g_profession" name="g2_profession">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="f_nid" class="col-sm-3 col-form-label">NID</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="f_nid" placeholder="NID Number" name="g2_nid">
									    </div>
									</div>
								
									<div class="form-group tab_select row">
										<label class="col-sm-3">Area</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="g2_area">
											    <option value="">Select Area..</option>
											    <option value="january">Dhaka</option>
											    <option value="february">Pabna</option>
											</select>
										</div>
									</div>	
									<div class="form-group tab_select row">
										<label class="col-sm-3">Police Station</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="g2_ps_id">
											    <option value="">Select Police Station..</option>
											    <option value="january">Dhaka</option>
											    <option value="february">Pabna</option>
											</select>
									 </div>

									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">City</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="g2_city">
											    <option value="">Select City..</option>
											    <option value="january">Dhaka</option>
											    <option value="february">Pabna</option>
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">District</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="g2_district">
											    <option value="">Select District..</option>
											    <option value="january">Dhaka</option>
											    <option value="february">Pabna</option>
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">Country</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="g2_country">
											    <option value="">Select Country..</option>
											    <option value="january">Mohammadpur</option>
											    <option value="february">Uttara</option>
											</select>
										</div>
									</div>
									<div class="regis_button tab_sub">
									  	<button>save</button>
									</div>
								</div>
							</form>
							</div>
							<!-- student information -->
							<div class="tab-pane fade" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
								<form action="#" method="post">
								@csrf
								@method('put')
								<div class="student_inform">
									<h4>Student information</h4>
									<div class="form-group row">
									    <label for="g_name" class="col-sm-3 col-form-label">Student Name</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="g_name" placeholder="Gueardian Name" name="name">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_class" class="col-sm-3 col-form-label">Class/Grade/Level</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="s_class" placeholder="lass/Grade/Level" name="class_grade_lebel">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_group" class="col-sm-3 col-form-label">Group</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="s_group" placeholder="Group Science/ Commerce/ Humanities/ Mixed" name="group">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_subject" class="col-sm-3 col-form-label">Subjects Pursuing</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="s_subject" placeholder="Subjects Pursuing" name="subject">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_phn" class="col-sm-3 col-form-label">Contact Number</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="s_phn" placeholder="Contact Number" name="phone">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_email" class="col-sm-3 col-form-label">Email</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="s_email" placeholder="Email Address" name="email">
									    </div>
									</div>
									<div class="form-group row">
									    <label for="s_address" class="col-sm-3 col-form-label">Address</label>
									    <div class="col-sm-9">
									      <textarea class="form-control" id="s_address" placeholder=" House Name, House, Flat, Road, Police Station" name="address"></textarea>
									    </div>
									</div>
									
									<div class="form-group tab_select row">
										<label class="col-sm-3">Area</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="area">
											    <option value="">Select Area..</option>
											     @foreach($allarea as $area)
											      <option value="{{$area->id}}">{{$area->area_name}}</option>
											     @endforeach
											</select>
										</div>
									</div>	
									<div class="form-group tab_select row">
										<label class="col-sm-3">Police Station</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="ps_id">
											    <option value="">Select Police Station..</option>
											    <option value="january">Dhaka</option>
											    <option value="february">Pabna</option>
											</select>
									 </div>

									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">City</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="city">
											    <option value="">Select City..</option>
											    <option value="january">Dhaka</option>
											    <option value="february">Pabna</option>
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">District</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="district">
											    <option value="">Select District..</option>
											    <option value="january">Dhaka</option>
											    <option value="february">Pabna</option>
											</select>
										</div>
									</div>
									<div class="form-group tab_select row">
										<label class="col-sm-3">Country</label>
										<div class="col-sm-9">
											<select id="selectboxx" class="form-control" name="country">
											    <option value="">Select Country..</option>
											    <option value="january">Mohammadpur</option>
											    <option value="february">Uttara</option>
											</select>
										</div>
									</div>
								
									<div class="regis_button tab_sub">
									  	<button>save</button>
									</div>
								</div>
							</form>
							</div>
						
						</div>
					</div>
				</div>
			</div>
		</section>

@endsection