@extends('layouts.frontend')
@section('content')

		<!-- subject-area -->
		<section class="subject-area">
			<div class="container">
				<div class="row">
						@include('frontend.template-parts.student_sidebar')
					<div class="sub-content sub-content2 col-md-10 wow fadeInDown">
						<div class="row">
							<div class="snotice_all">
								<h4>notice for students</h4>
								<div class="snotice_single">
									<h5>Notice For Vacation</h5>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Laelius clamores sofòw ille so lebat Edere compellans gumias ex ordine nostros. Itaque hic ipse iam pridem est reiectus; Lorem ipsum dolor sit amet, consectetur adipiscing elit. Laelius clamores sofòw ille so lebat Edere compellans gumias ex ordine nostros. Itaque hic ipse iam pridem est reiectus; </p>
									<form>
										<div class="form-group">
											<label for="1st">Leave a comment...</label>
										    <textarea class="form-control" id="1st" placeholder="Write a comment.."></textarea>
										</div>
										<div class="regis_button cmnt_btn">
										  	<button type="submit">comment</button>
										</div>
									</form>
								</div>
								<div class="snotice_single">
									<h5>Notice For Vacation</h5>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Laelius clamores sofòw ille so lebat Edere compellans gumias ex ordine nostros. Itaque hic ipse iam pridem est reiectus; Lorem ipsum dolor sit amet, consectetur adipiscing elit. Laelius clamores sofòw ille so lebat Edere compellans gumias ex ordine nostros. Itaque hic ipse iam pridem est reiectus; </p>
									<form>
										<div class="form-group">
											<label for="2nd">Leave a comment...</label>
										    <textarea class="form-control" id="2nd" placeholder="Write a comment.."></textarea>
										</div>
										<div class="regis_button cmnt_btn">
										  	<button type="submit">comment</button>
										</div>
									</form>
								</div>
								<div class="snotice_single">
									<h5>Notice For Vacation</h5>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Laelius clamores sofòw ille so lebat Edere compellans gumias ex ordine nostros. Itaque hic ipse iam pridem est reiectus; Lorem ipsum dolor sit amet, consectetur adipiscing elit. Laelius clamores sofòw ille so lebat Edere compellans gumias ex ordine nostros. Itaque hic ipse iam pridem est reiectus; </p>
									<form>
										<div class="form-group">
											<label for="3rd">Leave a comment...</label>
										    <textarea class="form-control" id="3rd" placeholder="Write a comment.."></textarea>
										</div>
										<div class="regis_button cmnt_btn">
										  	<button>comment</button>
										</div>
									</form>
								</div>
								<div class="all_notice">
									<a href="#">all notice</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

@endsection