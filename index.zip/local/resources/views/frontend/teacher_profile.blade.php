@extends('layouts.frontend')
@section('content')
	<!-- subject-area -->
	<section class="subject-area">
		<div class="container">
			<div class="row">
				  	@include('frontend.template-parts.search-result-sidebar')
				<div class="sub-content scroll col-md-9 wow fadeInDown">
					<h2>teacher profile</h2>
					<!-- sub_content_single-->
					<div class="teacher_img">
							@if($view_profile->photo != 'noimage.jpg')
								<img src="{{asset('local/public/contents/upload/teacher/profile')}}/{{$view_profile->photo}}">
							@else
							 <img src="{{asset('local/public/contents/frontend/images/noimage.jpg')}}" alt="image">
							@endif
						
						<h4>{{$view_profile->name}}</h4>
						<p>{{$view_profile->address}}</p>
						<ul>
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
						</ul>
						<h4>{{$view_profile->phone}}</h4>
					</div>
					<div class="teacher_des">
						<p>{{$view_profile->about}}</p>
					</div>
					<!-- profile-info -->
					<div class="profile-info" style="overflow:hidden">
						<h3>profession</h3>
						<div class="row">
							<div class="col-lg-4 col-sm-6">
								<h4>Teaching Levels</h4>
								<p>{{$view_profile->teaching_level}}</p>
							</div>
							<div class="col-lg-4 col-sm-6">
								<h4>Present School: {{$view_profile->present_school}}</h4>
								<p>Joining date: {{Carbon\Carbon::parse($view_profile->present_joining_date)->format('d-M-y')}}</p>
								<p>Position: {{$view_profile->present_position}}</p>
							</div>
							<div class="col-lg-4 col-sm-6">
								<h4>Last School: {{$view_profile->last_school}}</h4>
								<p>Till the Last Worked: {{Carbon\Carbon::parse($view_profile->last_joning_date)->format('d-M-y')}}</p>
								<p>Position: {{$view_profile->last_position}}</p>
							</div>
						</div>
					</div>
					<!-- profile-info -->
					<div class="profile-info">
						<h3>education</h3>
						<div class="row">
							<div class="col-lg-3 col-sm-6">
								<h4>SSC</h4>
								<p>{{$view_profile->olavel_or_ssc_ins}}</p>
								<p>Major: {{$view_profile->olavel_or_ssc_major}}</p>
								<p>Year: {{$view_profile->olavel_or_ssc_year}}</p>
							</div>
							<div class="col-lg-3 col-sm-6">
								<h4>HSC</h4>
								<p>Institution: {{$view_profile->olavel_or_ssc_ins}}</p>
								<p>Major: {{$view_profile->olavel_or_ssc_major}}</p>
								<p>Year: {{$view_profile->olavel_or_ssc_year}}</p>
							</div>
							<div class="col-lg-3 col-sm-6">
								<h4>BA (Honours)</h4>
								<p>Institution: {{$view_profile->bachelor_degree_ins}}</p>
								<p>Major: {{$view_profile->bachelor_degree_major}}</p>
								<p>Year: {{$view_profile->bachelor_degree_year}}</p>
							</div>
							<div class="col-lg-3 col-sm-6">
								<h4>MA(Masters)</h4>
								<p>Institution: {{$view_profile->master_degree_ins}}</p>
								<p>Major: {{$view_profile->master_degree_major}}</p>
								<p>Year: {{$view_profile->master_degree_yar}}</p>
							</div>
						</div>
					</div>
					<!-- profile-info -->
					<div class="profile-info">
						<h3>Attached Coaching Place(s)</h3>
						<p>When did the Coaching centre was established?: 
							{{ \Carbon\Carbon::parse($view_profile->coaching_establish_date)->format('d/m/Y')}}</p>
						<p>{{$view_profile->other_subject}}</p>
					</div>
					<!-- profile-info -->
					<div class="profile-info">
						<h3>Teaching Place(s)</h3>
                        @foreach($teaching_place as $t_place)
                        <?php  $police = 'App\Models\police_station'::where('id', $t_place->p_station)->get();
                        
                        ?>
                        <hr>
						<div class="row">
							<div class="col-lg-4 col-sm-6">
								<h4>Teaching Place: </h4>
								<p>Coaching Center Name:{{$t_place->coaching_name}}</p>
								<p>House: {{$t_place->house}}</p>
								<p>Road Number: {{$t_place->road_no}}</p>
							</div>
							<div class="col-lg-4 col-sm-6">
								<p>Police Station:
								 @foreach($police as $p)
                          	        {{ $p->police_station }}
                          	   @endforeach
                          </p>
								<p>Area: {{$t_place->area}}</p>
								<p>Post Office: {{$t_place->post_office}}</p>
							</div>
							<div class="col-lg-4 col-sm-6">
								<p>Postal Code: {{$t_place->post_code}}</p>
								<p>District: {{$t_place->t_place_district->district_name}}</p>
								<p>Country: {{$t_place->t_place_country->country_name}}</p>
							</div>
						</div>
						@endforeach
					</div>
					<!-- profile-info -->
					<div class="profile-info">
						<h3>Teaching Training(s)</h3>
						<table class="table table-bordered ">
						  <thead class="">
						    <tr>
						      <th scope="col">Date</th>
						      <th scope="col">Qualification</th>
						      <th scope="col">Training on</th>
						      <th scope="col">Duration</th>
						      <th scope="col">Given by</th>
						      <th scope="col">Organized by</th>
						      <th scope="col">Trainer(s)</th>
						      <th scope="col">Venue</th>
						    </tr>
						  </thead>
						  <tbody>
						  	@foreach($view_t_traning as $t_traning)
						    <tr>
						      <th scope="row">{{$t_traning->traning_date}}</th>
						      <td>{{$t_traning->qualification}}</td>
						      <td>{{$t_traning->traning_on}}</td>
						      <td>{{$t_traning->traning_duration}}</td>
						      <td>{{$t_traning->given_by}}</td>
						      <td>{{$t_traning->organization}}</td>
						      <td>{{$t_traning->trainer_name}}</td>
						      <td>{{$t_traning->t_venue}}</td>
						    </tr>
						    @endforeach
						  </tbody>
						
						</table>
					</div>
					<!-- profile-info -->
					<div class="profile-info">
						<h3>Address</h3>
						<p>{{$view_profile->address}}</p>
						<h4 style="padding-bottom: 10px;">Address on Google Map</h4>
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3652.1703918980825!2d90.38039151452398!3d23.74130248459384!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8b7a55cd36f%3A0xfcc5b021faff43ea!2sCreative%20IT%20Institute!5e0!3m2!1sen!2sbd!4v1568804774459!5m2!1sen!2sbd" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
					</div>

				</div>
			</div>
		</div>
	</section>



	
@endsection